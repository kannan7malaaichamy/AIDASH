"""AI Synapse database: schema, reference data, and sample-data seeding (SQLite)."""
import os
import random
import sqlite3
from datetime import date, timedelta

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "aidash.db")

# ---------------------------------------------------------------- database location
# Option 1: LOCAL SQLite file (active) - aidash.db next to this file. To switch to the cloud,
#           comment out the next line and uncomment Option 2.
DB_URL = None
#
# Option 2: SQLite CLOUD. Connects over HTTPS (port 443) through cloud_db.py, because the
#           normal SQLite Cloud port 8860 is blocked on this network. The AIDASH_DB_URL environment
#           variable, if set, overrides the connection string below.
#           SECURITY: the apikey grants full access to the cloud database. Keep this file private, or
#           remove the key from here and set AIDASH_DB_URL instead.
# DB_URL = os.environ.get(
#     "AIDASH_DB_URL",
#     "sqlitecloud://cg8zphyqdz.g1.sqlite.cloud:8860/ai-dash?apikey=olvzTzFuIbWEZ6Cqlbu8zoaccKGvJKunlR2UeOsoS0Y")

# FY27 runs April 2026 - March 2027 (TCS fiscal year).
FY_START = (2026, 4)
LEVELS = ["L0", "L1", "L2", "L3", "L4", "L5"]

BG_ISU = {
    "BFSI Americas 1": ["BFSI Americas East 1", "BFSI Americas East 2"],
    "BFSI Americas 2": ["BFSI Americas Canada 1", "BFSI Americas Canada 2"],
    "BFSI RoW": ["BFSI Europe 1", "BFSI UK 1"],
    "Retail CPG": ["RetailCPG 1", "RetailCPG 2"],
    "TTH": ["TTH Americas 1", "TTH Americas 2", "TTH Canada 1"],
    "CMTS": ["CMTS 1", "CMTS 2", "CMTS 3", "CMTS 4"],
    "LSHC": ["LSHC 1", "LSHC 2", "LSHC 3"],
    "ERU": ["ERU Europe", "ERU Americas"],
    "MFG": ["MFG 1", "MFG 2", "MFG 3"],
    "USWC": ["USWC 1", "USWC 2", "USWC 3"],
}

# Synthetic customer-name stems per BG (combined with suffixes to reach 5+ per ISU).
NAME_POOL = {
    "BFSI Americas 1": ["Nationwide", "USAA", "SCSC Bank", "Royal", "Harborline", "Keystone Mutual",
                        "Granite Trust", "Liberty Crest", "Summit Federal", "Atlantic Shield"],
    "BFSI Americas 2": ["Maple Leaf", "Northern Pine", "Laurentian", "Prairie Trust", "Great Lakes",
                        "Ottawa Capital", "Borealis", "Cascade Mutual", "Hudson Bay", "Red River"],
    "BFSI RoW": ["Thames", "Albion", "Rhine Capital", "Nordic Union", "Iberia Mutual",
                 "Alpine Trust", "Baltic", "Celtic", "Danube", "Lombard"],
    "Retail CPG": ["FreshCart", "UrbanBasket", "PureLeaf", "Brightway", "HomeNest",
                   "Golden Grain", "Velvet Brands", "DailyMart", "Crisp Foods", "Evergreen Goods"],
    "TTH": ["SkyBridge", "TransRail", "BlueHarbor", "AeroNova", "Wayfarer",
            "PolarJet", "RouteOne", "Coastline", "Pinnacle Stays", "TrailStar"],
    "CMTS": ["NovaTel", "StreamWave", "PixelCast", "Orbit Media", "CloudCom",
             "SignalPeak", "Quantum Net", "Echo Studios", "Fibera", "Vertex Telecom"],
    "LSHC": ["CuraGen", "MediNova", "HealWell", "BioPath", "Vitalis",
             "Genexa", "CareBridge", "LifeSpring", "PharmaCore", "Helix Health"],
    "ERU": ["GridStar", "SolarWay", "AquaPure", "TerraPower", "BlueFlame",
            "VoltEdge", "HydroNorth", "WindCrest", "PetroLine", "EcoUtility"],
    "MFG": ["Ironclad", "PrecisionWorks", "AutoForge", "SteelCraft", "MechaTech",
            "Titan Motors", "AeroParts", "Ferro Industries", "Gearline", "Apex Manufacturing"],
    "USWC": ["Sierra Systems", "Redwood Tech", "Pacific Rim", "Golden Gate", "Cascade Labs",
             "Sequoia Digital", "Bayline", "Mojave Data", "Silverlake", "Coastal Cloud"],
}
SUFFIX = {
    "BFSI Americas 1": ["Insurance", "Bank", "Financial", "Banking", "Mutual"],
    "BFSI Americas 2": ["Bank", "Financial", "Insurance", "Credit Union", "Trust"],
    "BFSI RoW": ["Bank", "Insurance", "Capital", "Assurance", "Financial"],
}

LOOKUPS = {
    "engagement_type": ["CXO connect", "VP connect", "POC", "POT", "POV", "Workshop"],
    "role_type": ["AI Engineer", "FDE", "Test Engineer"],
    "asset_status": ["Ideation", "In development", "Ready for use", "Deployed", "Retired"],
}
HEADCOUNT_BANDS = ["Zero", "Less than 30", "30 or more", "Pending business confirmation"]
DEAL_TYPES = ["RFP", "Proactive proposal", "Renewal", "New logo"]
DEAL_STATUSES = ["In progress", "RFP submitted", "Presentation", "Negotiation", "Won", "Lost"]
PLAN_STATUSES = ["Not started", "In progress", "Done", "Blocked"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS bg (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL,
    spoc_name TEXT, spoc_email TEXT, spoc_emp_no TEXT);
CREATE TABLE IF NOT EXISTS isu (id INTEGER PRIMARY KEY, bg_id INTEGER NOT NULL REFERENCES bg(id),
    name TEXT NOT NULL, spoc_name TEXT, spoc_email TEXT, spoc_emp_no TEXT, UNIQUE(bg_id, name));
CREATE TABLE IF NOT EXISTS customer (id INTEGER PRIMARY KEY, isu_id INTEGER NOT NULL REFERENCES isu(id),
    name TEXT NOT NULL, spoc_name TEXT, spoc_email TEXT, spoc_emp_no TEXT);
CREATE TABLE IF NOT EXISTS lookup (id INTEGER PRIMARY KEY, category TEXT NOT NULL, value TEXT NOT NULL,
    UNIQUE(category, value));

CREATE TABLE IF NOT EXISTS autonomy (
    customer_id INTEGER PRIMARY KEY REFERENCES customer(id),
    workshop_completed TEXT, mega_ai_journey TEXT, headcount_band TEXT,
    target_level TEXT, target_quarter TEXT);
CREATE TABLE IF NOT EXISTS plan_item (
    id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customer(id),
    item TEXT NOT NULL, owner TEXT, due_date TEXT, status TEXT);
CREATE TABLE IF NOT EXISTS assessment (
    id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customer(id),
    type TEXT NOT NULL, score REAL, level TEXT NOT NULL, assessment_date TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS deal (
    id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customer(id),
    opportunity_id TEXT, opportunity_type TEXT, deal_name TEXT, description TEXT, status TEXT,
    client_context TEXT, past_failure_reasons TEXT, deal_size TEXT, deal_value REAL,
    pursuit_lead TEXT, pitch_focus TEXT, resonated TEXT, not_resonated TEXT,
    entry_date TEXT, reporting_month TEXT, win_team TEXT, competitor TEXT);

CREATE TABLE IF NOT EXISTS touchpoint (
    id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customer(id),
    engagement_type TEXT, customer_participants TEXT, tcs_participants TEXT,
    focus_areas TEXT, reporting_month TEXT);

CREATE TABLE IF NOT EXISTS engineer (
    id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customer(id),
    associate_name TEXT NOT NULL, employee_number TEXT NOT NULL UNIQUE, location TEXT,
    role_type TEXT, month_added TEXT);

CREATE TABLE IF NOT EXISTS app_user (
    id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL COLLATE NOCASE,
    password_hash TEXT NOT NULL, full_name TEXT, is_admin INTEGER NOT NULL DEFAULT 0, scope_bg TEXT, scope_isu TEXT);

CREATE TABLE IF NOT EXISTS asset (
    id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL REFERENCES customer(id),
    asset_name TEXT, description TEXT, status TEXT, contribution_month TEXT,
    asset_count INTEGER, contributor TEXT, core_platform TEXT);
"""


def connect():
    if DB_URL:   # Option 2: SQLite Cloud (foreign keys are already enforced there)
        import cloud_db
        return cloud_db.connect(DB_URL)
    conn = sqlite3.connect(DB_PATH)   # Option 1: local file
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def where():
    """Human-readable database location (the API key is never shown)."""
    if DB_URL:
        from urllib.parse import urlparse
        u = urlparse(DB_URL)
        return f"SQLite Cloud {u.hostname}/{u.path.strip('/')} (HTTPS)"
    return DB_PATH


def fy_months(today=None):
    """'YYYY-MM' strings from FY27 April up to the current month."""
    today = today or date.today()
    y, m = FY_START
    out = []
    while (y, m) <= (today.year, today.month):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out or [f"{FY_START[0]:04d}-{FY_START[1]:02d}"]


def fy_quarters(today=None):
    """[(code, label, [months])] for FY quarters that have started (Q1 = Apr-Jun)."""
    out = {}
    for ym in fy_months(today):
        y, m = map(int, ym.split("-"))
        fy = y + 1 if m >= 4 else y
        q = (m - 4) % 12 // 3 + 1
        code = f"Q{q} FY{fy % 100:02d}"
        out.setdefault(code, []).append(ym)
    spans = ["Apr-Jun", "Jul-Sep", "Oct-Dec", "Jan-Mar"]
    return [(code, f"{code} ({spans[int(code[1]) - 1]})", ms) for code, ms in out.items()]


def month_end(ym):
    y, m = map(int, ym.split("-"))
    nxt = date(y + (m == 12), m % 12 + 1, 1)
    return (nxt - timedelta(days=1)).isoformat()


def month_label(ym):
    y, m = map(int, ym.split("-"))
    return date(y, m, 1).strftime("%b-%y")


def score_to_level(score):
    return LEVELS[min(5, int(score // 20))]


def init_db(reset=False):
    if reset and DB_URL:   # never wipe the shared cloud database from here
        raise SystemExit("Refusing to reset: AIDASH is set to SQLite Cloud. Reset is only for the local file "
                         "(switch db.py to Option 1 first).")
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = connect()
    conn.executescript(SCHEMA)
    if conn.execute("SELECT COUNT(*) FROM bg").fetchone()[0] == 0:
        seed(conn)
        fill_sample_spocs(conn)
        fill_sample_lead_spocs(conn, "bg")
        fill_sample_lead_spocs(conn, "isu")
    # migration: Account AI-SPOC columns on customer; populate sample SPOCs once when they are added
    ccols = [r["name"] for r in conn.execute("PRAGMA table_info(customer)")]
    if "spoc_name" not in ccols:
        for col in ("spoc_name", "spoc_email", "spoc_emp_no"):
            conn.execute(f"ALTER TABLE customer ADD COLUMN {col} TEXT")
        fill_sample_spocs(conn)
    # migration: Account AI-SPOC columns on BG and ISU; populate sample SPOCs once when they are added
    for table in ("bg", "isu"):
        tcols = [r["name"] for r in conn.execute(f"PRAGMA table_info({table})")]
        if "spoc_name" not in tcols:
            for col in ("spoc_name", "spoc_email", "spoc_emp_no"):
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} TEXT")
            fill_sample_lead_spocs(conn, table)
    # migration: role column for databases created before roles existed; 'admin' is always an admin
    cols = [r["name"] for r in conn.execute("PRAGMA table_info(app_user)")]
    if "is_admin" not in cols:
        conn.execute("ALTER TABLE app_user ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0")
        conn.execute("UPDATE app_user SET is_admin=1 WHERE username='admin'")
    if "scope_bg" not in cols:   # BG-scoped users (NULL = all BGs)
        conn.execute("ALTER TABLE app_user ADD COLUMN scope_bg TEXT")
    if "scope_isu" not in cols:   # ISU-scoped users (NULL = no ISU limit); their BG is the ISU's BG
        conn.execute("ALTER TABLE app_user ADD COLUMN scope_isu TEXT")
    if conn.execute("SELECT COUNT(*) FROM app_user").fetchone()[0] == 0:
        add_user(conn, "admin", "admin123", "Administrator", is_admin=True)
    conn.commit()
    conn.close()


SPOC_GIVEN = ["Venkat", "Priya", "Arun", "Lakshmi", "Suresh", "Deepa", "Ramesh", "Anitha", "Karthik", "Meena",
              "Vijay", "Revathi", "Prakash", "Kavitha", "Senthil", "Divya", "Ganesh", "Swathi", "Hari", "Nandini"]
SPOC_SURNAME = ["Kumar", "Raman", "Iyer", "Nair", "Reddy", "Menon", "Sharma", "Rao", "Pillai", "Krishnan",
                "Subramanian", "Natarajan", "Gupta", "Patel", "Srinivasan"]


def sample_spoc(rnd):
    """(name, email, emp_no) in the format of the example: "Kumar Venkat", venkat.kumar@tcs.com, 129786."""
    given, surname = rnd.choice(SPOC_GIVEN), rnd.choice(SPOC_SURNAME)
    return f"{surname} {given}", f"{given.lower()}.{surname.lower()}@tcs.com", str(rnd.randint(100000, 999999))


LEAD_GIVEN = ["Venu", "Shankar", "Radha", "Mohan", "Geetha", "Balaji", "Usha", "Krishna", "Sundar", "Padma",
              "Ravi", "Sarala", "Murali", "Janaki", "Anand", "Vasanthi", "Sekar", "Bhavani"]


def sample_lead_spoc(rnd):
    """BG/ISU SPOC in the format of the example: "Venu Iyer", venu.iyer@tcs.com, 29786."""
    given, surname = rnd.choice(LEAD_GIVEN), rnd.choice(SPOC_SURNAME)
    return f"{given} {surname}", f"{given.lower()}.{surname.lower()}@tcs.com", str(rnd.randint(10000, 99999))


def fill_sample_lead_spocs(conn, table):
    rnd = random.Random(29786 + (0 if table == "bg" else 1))
    for (rid,) in conn.execute(f"SELECT id FROM {table} WHERE spoc_name IS NULL ORDER BY id").fetchall():
        conn.execute(f"UPDATE {table} SET spoc_name=?, spoc_email=?, spoc_emp_no=? WHERE id=?",
                     (*sample_lead_spoc(rnd), rid))


def fill_sample_spocs(conn):
    rnd = random.Random(129786)
    for (cid,) in conn.execute("SELECT id FROM customer WHERE spoc_name IS NULL ORDER BY id").fetchall():
        conn.execute("UPDATE customer SET spoc_name=?, spoc_email=?, spoc_emp_no=? WHERE id=?", (*sample_spoc(rnd), cid))


def add_user(conn, username, password, full_name="", is_admin=False, scope_bg=None, scope_isu=None):
    """Create or update a user. scope_bg limits them to one BG; scope_isu limits them to one ISU (its BG is implied)."""
    from werkzeug.security import generate_password_hash
    if scope_bg and not conn.execute("SELECT 1 FROM bg WHERE name=?", (scope_bg,)).fetchone():
        raise ValueError(f"Unknown BG '{scope_bg}'. Valid BGs: "
                         + ", ".join(r[0] for r in conn.execute("SELECT name FROM bg ORDER BY id")))
    if scope_isu:
        r = conn.execute("SELECT b.name FROM isu i JOIN bg b ON b.id=i.bg_id WHERE i.name=?", (scope_isu,)).fetchone()
        if not r:
            raise ValueError(f"Unknown ISU '{scope_isu}'. Valid ISUs: "
                             + ", ".join(x[0] for x in conn.execute("SELECT name FROM isu ORDER BY bg_id, id")))
        if scope_bg and scope_bg != r[0]:
            raise ValueError(f"ISU '{scope_isu}' belongs to BG '{r[0]}', not '{scope_bg}'.")
        scope_bg = None   # the BG always follows the ISU, so it is not stored separately
    conn.execute("""INSERT INTO app_user(username, password_hash, full_name, is_admin, scope_bg, scope_isu)
        VALUES (?,?,?,?,?,?)
        ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash, full_name=excluded.full_name,
        is_admin=excluded.is_admin, scope_bg=excluded.scope_bg, scope_isu=excluded.scope_isu""",
                 (username, generate_password_hash(password), full_name, 1 if is_admin else 0, scope_bg or None,
                  scope_isu or None))


def seed(conn):
    rnd = random.Random(27)
    months = fy_months()

    for cat, vals in LOOKUPS.items():
        conn.executemany("INSERT INTO lookup(category, value) VALUES (?, ?)", [(cat, v) for v in vals])

    customers = []
    for bg, isus in BG_ISU.items():
        bg_id = conn.execute("INSERT INTO bg(name) VALUES (?)", (bg,)).lastrowid
        pool = NAME_POOL[bg]
        sfx = SUFFIX.get(bg, ["Inc", "Corp", "Group", "Holdings", "Co"])
        for i, isu in enumerate(isus):
            isu_id = conn.execute("INSERT INTO isu(bg_id, name) VALUES (?, ?)", (bg_id, isu)).lastrowid
            for j in range(5):
                stem = pool[(i * 5 + j) % len(pool)]
                name = f"{stem} {sfx[(i + j) % len(sfx)]}"
                cid = conn.execute("INSERT INTO customer(isu_id, name) VALUES (?, ?)", (isu_id, name)).lastrowid
                customers.append((cid, name))

    first = ["Arjun", "Priya", "Rahul", "Ananya", "Vikram", "Sneha", "Karthik", "Divya", "Rohan", "Meera",
             "Sanjay", "Lakshmi", "Aditya", "Kavya", "Nikhil", "Pooja", "John", "Emily", "Michael", "Sarah"]
    last = ["Sharma", "Iyer", "Nair", "Reddy", "Gupta", "Menon", "Rao", "Patel", "Kumar", "Singh",
            "Smith", "Brown", "Wilson", "Clark"]
    person = lambda: f"{rnd.choice(first)} {rnd.choice(last)}"
    plan_items = ["Identify AI use-case backlog", "Set up AI CoE governance", "Upskill team on GenAI tooling",
                  "Automate L1 ticket triage", "Deploy agentic test automation", "Baseline productivity metrics",
                  "Integrate AI code assistant", "Run value realisation review"]
    focus = ["GenAI-led operations", "Agentic automation", "Cloud modernisation", "Data platform",
             "Customer experience", "Cost take-out", "Cyber resilience", "AI for testing"]
    locations = ["Chennai", "Bengaluru", "Pune", "Mumbai", "Hyderabad", "Kolkata", "New York", "Toronto",
                 "London", "Dallas", "Phoenix", "Cincinnati"]
    competitors = ["Accenture", "Infosys", "Cognizant", "Wipro", "HCLTech", "Capgemini", "IBM", "Deloitte"]

    def rand_day(ym):
        y, m = map(int, ym.split("-"))
        return date(y, m, rnd.randint(1, 28)).isoformat()

    emp_no = 2100000
    for cid, cname in customers:
        # --- AI service autonomy ---
        conn.execute("INSERT INTO autonomy VALUES (?,?,?,?,?,?)", (
            cid, rnd.choice("YYN"), rnd.choice("YN"), rnd.choice(HEADCOUNT_BANDS),
            rnd.choice(["L3", "L4", "L4", "L5"]), rnd.choice(["Q3 FY27", "Q4 FY27", "Q1 FY28", "Q2 FY28"])))
        for item in rnd.sample(plan_items, 3):
            conn.execute("INSERT INTO plan_item(customer_id, item, owner, due_date, status) VALUES (?,?,?,?,?)",
                         (cid, item, person(), rand_day(rnd.choice(months)), rnd.choice(PLAN_STATUSES)))
        # baseline early in the FY, then 0-3 reassessments with a rising score
        score = rnd.uniform(15, 50)
        start = rnd.randint(0, max(0, min(2, len(months) - 1)))
        conn.execute("INSERT INTO assessment(customer_id, type, score, level, assessment_date) VALUES (?,?,?,?,?)",
                     (cid, "Baseline", round(score, 1), score_to_level(score), rand_day(months[start])))
        idx = start
        for _ in range(rnd.randint(0, 3)):
            idx += rnd.randint(1, 2)
            if idx >= len(months):
                break
            score = min(95, score + rnd.uniform(4, 18))
            conn.execute("INSERT INTO assessment(customer_id, type, score, level, assessment_date) VALUES (?,?,?,?,?)",
                         (cid, "Reassessment", round(score, 1), score_to_level(score), rand_day(months[idx])))

        # --- Key deals ---
        for k in range(rnd.randint(0, 2)):
            ym = rnd.choice(months)
            status = rnd.choice(DEAL_STATUSES + ["Won"])
            otype = rnd.choice(DEAL_TYPES)
            f = rnd.choice(focus)
            value = round(rnd.uniform(0.5, 60), 1)
            conn.execute("""INSERT INTO deal(customer_id, opportunity_id, opportunity_type, deal_name, description,
                status, client_context, past_failure_reasons, deal_size, deal_value, pursuit_lead, pitch_focus,
                resonated, not_resonated, entry_date, reporting_month, win_team, competitor)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                cid, f"OPP-{cid:03d}{k}{rnd.randint(10, 99)}", otype, f"{cname.split()[0]} {f}",
                f"{otype} for {f.lower()} across {cname}'s core estate",
                status, f"{cname} is consolidating vendors and wants measurable AI outcomes",
                rnd.choice(["", "Pricing not competitive in last cycle", "Incumbent relationship too strong",
                            "Solution lacked domain depth", ""]),
                "Large" if value > 25 else "Medium" if value > 8 else "Small", value, person(),
                f"{f}; outcome-based pricing; AI-first delivery",
                rnd.choice(["Outcome-based pricing", "Live demo of agents", "Domain accelerators", "Transition approach"]),
                "" if status != "Lost" else rnd.choice(["Price", "Incumbent advantage", "Scope mismatch"]),
                rand_day(ym), ym, f"{person()}, {person()}" if status == "Won" else "",
                rnd.choice(competitors)))

        # --- Customer touchpoints ---
        for _ in range(rnd.randint(1, 4)):
            conn.execute("""INSERT INTO touchpoint(customer_id, engagement_type, customer_participants,
                tcs_participants, focus_areas, reporting_month) VALUES (?,?,?,?,?,?)""", (
                cid, rnd.choice(LOOKUPS["engagement_type"]),
                f"{person()} (CIO), {person()} (VP Eng)", f"{person()}, {person()}",
                ", ".join(rnd.sample(focus, 2)), rnd.choice(months)))

        # --- Distinguished engineers ---
        for _ in range(rnd.randint(0, 2)):
            emp_no += rnd.randint(1, 900)
            conn.execute("""INSERT INTO engineer(customer_id, associate_name, employee_number, location,
                role_type, month_added) VALUES (?,?,?,?,?,?)""", (
                cid, person(), str(emp_no), rnd.choice(locations),
                rnd.choice(LOOKUPS["role_type"]), rnd.choice(months)))

        # --- Asset contributions ---
        for _ in range(rnd.randint(0, 2)):
            nm = rnd.choice(["Agentic Ticket Router", "Test Case Generator", "Claims Copilot", "Code Review Bot",
                             "Data Quality Agent", "KYC Extractor", "Incident RCA Assistant", "Demand Forecaster"])
            conn.execute("""INSERT INTO asset(customer_id, asset_name, description, status, contribution_month,
                asset_count, contributor, core_platform) VALUES (?,?,?,?,?,?,?,?)""", (
                cid, nm, f"{nm} built for {cname}", rnd.choice(LOOKUPS["asset_status"]),
                rnd.choice(months), rnd.randint(1, 3), person(), rnd.choice("YN")))


if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 4 and sys.argv[1] == "adduser":
        # python db.py adduser <username> <password> [full name] [--admin] [--bg "<BG name>"]
        init_db()
        # optional: --isu "<ISU name>" limits the user to one ISU
        args = sys.argv[4:]
        scopes = {}
        for flag in ("--bg", "--isu"):
            if flag in args:
                i = args.index(flag)
                scopes[flag] = args[i + 1] if i + 1 < len(args) else None
                args = args[:i] + args[i + 2:]
        scope, scope_isu = scopes.get("--bg"), scopes.get("--isu")
        admin = "--admin" in args or sys.argv[2].lower() == "admin"
        name = " ".join(a for a in args if a != "--admin")
        c = connect()
        try:
            add_user(c, sys.argv[2], sys.argv[3], name, is_admin=admin, scope_bg=scope, scope_isu=scope_isu)
        except ValueError as e:
            sys.exit(str(e))
        c.commit()
        c.close()
        print(f"User '{sys.argv[2]}' saved{' (admin)' if admin else ''}{f' (ISU: {scope_isu})' if scope_isu else f' (BG: {scope})' if scope else ''}.")
    else:
        init_db(reset=True)
        print("Database created and seeded at", DB_PATH)
