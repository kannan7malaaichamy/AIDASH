"""AI Agents page (admin only): one-click agents that draft reminder emails as Notepad (.txt) files.

1. Send Reminder All SPOCs   -> one email to every customer AccountAI-SPOC (Bcc), saved as
                                aidatafillreminderEmail_<timestamp>.txt in GENERAL_DIR
2. Sync CRM Data             -> placeholder, no action yet
3. Follow Up on Missing Info -> one email per customer SPOC listing only that SPOC's missing data for the
                                current month, saved as aimissingdata<empid>_<timestamp>.txt in SPECIAL_DIR
4. Motivation Agent          -> per ISU, finds the top 5 customers on AI Service Autonomy L2 / L3 progression and
                                drafts a motivation email to every other customer SPOC in that ISU (not the top-5
                                SPOCs), saved as motivation<empid>_<timestamp>.txt in MOTIVATION_DIR

Claude writes the wording (subject + body with placeholders). Facts - recipients, customers, missing items,
dates - are filled in by AIDASH from the database, so the AI cannot invent a gap or an address. If the AI
is unavailable, a standard template is used and the page says so. Emails are only drafted, never sent.
"""
import json
import os
import re
from collections import OrderedDict
from datetime import date, datetime

from flask import Blueprint, abort, g, render_template, request, session

MODEL = "claude-opus-5-5"
GENERAL_DIR = r"C:\Users\GenAICHNSIRUSR49\aidash-email\general-reminders"
SPECIAL_DIR = r"C:\Users\GenAICHNSIRUSR49\aidash-email\special-reminders"
MOTIVATION_DIR = r"C:\Users\GenAICHNSIRUSR49\aidash-email\motivation"
PORTAL = "AI Synapse - TCS AI Journey Insights Portal"

bp = Blueprint("agents", __name__)
H = {}


def init(app, **helpers):
    H.update(helpers)
    app.register_blueprint(bp)


def _admin():
    if not g.is_admin:
        abort(403)


# ---------------------------------------------------------------- shared helpers
def month_info():
    ym = H["current_month"]()
    return {"ym": ym, "label": H["db"].month_label(ym), "due": H["db"].month_end(ym),
            "due_label": datetime.strptime(H["db"].month_end(ym), "%Y-%m-%d").strftime("%d %b %Y")}


def stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def sender():
    return session.get("full_name") or session.get("user") or "AI Synapse Admin"


def first_name(spoc_name, email):
    """Sample data stores names as 'Surname Given' and emails as given.surname@tcs.com: prefer the email."""
    local = (email or "").split("@")[0]
    if "." in local:
        return local.split(".")[0].capitalize()
    return (spoc_name or "").split()[-1] if spoc_name else "there"


def write_txt(folder, filename, to, cc, bcc, subject, body):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, filename)
    lines = [f"To: {to}"]
    if cc:
        lines.append(f"Cc: {cc}")
    if bcc:
        lines.append(f"Bcc: {bcc}")
    lines += [f"Subject: {subject}", "", body.strip(), ""]
    with open(path, "w", encoding="utf-8", newline="\r\n") as f:   # CRLF: opens cleanly in Notepad
        f.write("\n".join(lines))
    return path


def ai_draft(instructions, required_tokens):
    """Ask Claude for {"subject", "body"}. Returns (subject, body, None) or (None, None, reason)."""
    key = H["api_key"]()
    if not key:
        return None, None, "no Anthropic API key configured"
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=key)
        resp = client.beta.messages.create(
            model=MODEL,
            max_tokens=8000,
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",
            output_config={
                "effort": "medium",
                "format": {"type": "json_schema", "schema": {
                    "type": "object",
                    "properties": {"subject": {"type": "string"}, "body": {"type": "string"}},
                    "required": ["subject", "body"], "additionalProperties": False}},
            },
            system=("You write clear, professional internal emails for TCS (Tata Consultancy Services) account "
                    "teams on behalf of the AI Synapse portal administrators. Plain text only (no markdown, no "
                    "HTML). Warm but brief, specific about what to do and by when. Never invent names, numbers, "
                    "links or facts beyond what you are given."),
            messages=[{"role": "user", "content": instructions}],
        )
        if resp.stop_reason == "refusal":
            return None, None, "the AI declined the request"
        data = json.loads(next(b.text for b in resp.content if b.type == "text"))
        subject, body = data["subject"].strip(), data["body"].strip()
        missing = [t for t in required_tokens if t not in body]
        if missing:
            return None, None, "the AI draft left out " + ", ".join(missing)
        return subject, body, None
    except Exception as e:   # any API/network/parse problem -> standard template
        return None, None, f"AI unavailable ({type(e).__name__})"


# ---------------------------------------------------------------- agent 1: reminder to all SPOCs
def agent_general():
    c = H["conn"]()
    try:
        spocs = c.execute("""SELECT DISTINCT TRIM(spoc_email) e FROM customer
            WHERE spoc_email IS NOT NULL AND TRIM(spoc_email)<>'' ORDER BY e""").fetchall()
        n_cust = c.execute("SELECT COUNT(*) FROM customer").fetchone()[0]
        gaps = H["completeness"](c)
    finally:
        c.close()
    emails = [r["e"] for r in spocs]
    m = month_info()
    n_inc = sum(1 for v in gaps.values() if any(v.values()))
    sections = ", ".join(t for _, t in H["SECTIONS"])
    subject, body, why = ai_draft(
        f"Write ONE reminder email sent (Bcc) to all {len(emails)} AccountAI-SPOCs asking them to update their "
        f"accounts' data in the {PORTAL} for {m['label']}.\n"
        f"Facts you may use: sections to update: {sections}. Deadline: {m['due_label']}. "
        f"Right now {n_inc} of {n_cust} accounts have missing or incomplete data for {m['label']}. "
        f"Users can enter data on each page or simply describe it in the portal's AI Chat, which drafts the record "
        f"for them to confirm.\n"
        f"Address the readers generically (e.g. 'Dear AccountAI-SPOCs'). Sign off as: {sender()}, on behalf of the "
        f"AI Synapse team. Keep the body under 200 words. Use short '-' bullets for the sections.",
        required_tokens=[])
    used_ai = subject is not None
    if not used_ai:
        subject = f"Reminder: update your AI Synapse account data for {m['label']} by {m['due_label']}"
        body = (f"Dear AccountAI-SPOCs,\n\nThis is a reminder to update your accounts' data in the {PORTAL} for "
                f"{m['label']}. Please complete the following sections by {m['due_label']}:\n\n"
                + "\n".join(f"- {t}" for _, t in H["SECTIONS"]) +
                f"\n\nCurrently {n_inc} of {n_cust} accounts have missing or incomplete data for {m['label']}. "
                f"You can enter data on each page, or describe it in the AI Chat and confirm the draft it prepares.\n\n"
                f"Thank you for keeping the AI journey insights accurate.\n\nRegards,\n{sender()}\nOn behalf of the AI Synapse team")
    fname = f"aidatafillreminderEmail_{stamp()}.txt"
    path = write_txt(GENERAL_DIR, fname, to="AccountAI-SPOCs (recipients in Bcc)", cc="", bcc="; ".join(emails),
                     subject=subject, body=body)
    return {"agent": "Send Reminder All SPOCs", "used_ai": used_ai, "why": why, "folder": GENERAL_DIR,
            "files": [{"name": fname, "kind": "general", "to": f"{len(emails)} SPOCs (Bcc)"}],
            "preview": open(path, encoding="utf-8").read(),
            "summary": f"1 email drafted for {len(emails)} SPOCs ({n_inc} of {n_cust} accounts incomplete for {m['label']})."}


# ---------------------------------------------------------------- agent 3: follow up on missing info
def agent_missing():
    c = H["conn"]()
    try:
        gaps = H["completeness"](c)
        rows = c.execute("""SELECT cu.id, cu.name, cu.spoc_name, cu.spoc_email, cu.spoc_emp_no,
                i.name isu, i.spoc_email isu_email, b.name bg
            FROM customer cu JOIN isu i ON i.id=cu.isu_id JOIN bg b ON b.id=i.bg_id ORDER BY b.id, i.id, cu.name""").fetchall()
    finally:
        c.close()
    titles = dict(H["SECTIONS"])
    m = month_info()
    # group the accounts with gaps by their SPOC (emp no, else email)
    by_spoc = OrderedDict()
    no_spoc = []
    for r in rows:
        g_ = {k: v for k, v in gaps.get(r["id"], {}).items() if v}
        if not g_:
            continue
        key = (r["spoc_emp_no"] or "").strip() or (r["spoc_email"] or "").strip().lower()
        if not key:
            no_spoc.append(r["name"])
            continue
        s = by_spoc.setdefault(key, {"emp": (r["spoc_emp_no"] or "").strip(), "name": r["spoc_name"],
                                     "email": (r["spoc_email"] or "").strip(), "cc": set(), "accounts": []})
        if r["isu_email"]:
            s["cc"].add(r["isu_email"].strip())
        s["accounts"].append((r, g_))

    tokens = ["{{FIRST_NAME}}", "{{ACCOUNT_DETAILS}}", "{{DUE_DATE}}"]
    subj_t, body_t, why = ai_draft(
        "Write an email TEMPLATE that follows up with one AccountAI-SPOC about missing data in the "
        f"{PORTAL} for {m['label']}. It will be personalised by software, so use these placeholders exactly:\n"
        "- {{FIRST_NAME}} : the SPOC's first name (greeting)\n"
        "- {{ACCOUNT_DETAILS}} : a pre-formatted list of their accounts and exactly what is missing (put it on its "
        "own lines, do not describe it further)\n"
        "- {{DUE_DATE}} : the deadline date\n"
        "The subject may use {{DUE_DATE}} too. Mention they can fill the data on each page or describe it in the "
        "portal's AI Chat, which drafts the record for them to confirm; and to reply if any item does not apply. "
        f"Sign off as: {sender()}, on behalf of the AI Synapse team. Body under 170 words excluding the list.",
        required_tokens=tokens)
    used_ai = subj_t is not None
    if not used_ai:
        subj_t = f"Action needed: missing AI Synapse data for {m['label']} (due {{{{DUE_DATE}}}})"
        body_t = ("Dear {{FIRST_NAME}},\n\nOur records in the " + PORTAL + " show the following data is missing or "
                  f"incomplete for {m['label']} on your account(s):\n\n{{{{ACCOUNT_DETAILS}}}}\n\n"
                  "Please update these by {{DUE_DATE}}. You can fill them in on each page, or describe the details "
                  "in the AI Chat and confirm the draft it prepares. If any item does not apply to your account, "
                  f"just reply to this email and let us know.\n\nThank you,\n{sender()}\nOn behalf of the AI Synapse team")

    ts = stamp()
    files, first_path = [], None
    for key, s in by_spoc.items():
        lines = []
        for r, g_ in s["accounts"]:
            lines.append(f"{r['name']} ({r['isu']}, {r['bg']})")
            for sec, reasons in g_.items():
                lines.append(f"  - {titles.get(sec, sec)}: " + "; ".join(reasons))
            lines.append("")
        details = "\n".join(lines).rstrip()
        fill = {"{{FIRST_NAME}}": first_name(s["name"], s["email"]), "{{ACCOUNT_DETAILS}}": details,
                "{{DUE_DATE}}": m["due_label"]}
        subject, body = subj_t, body_t
        for t, v in fill.items():
            subject, body = subject.replace(t, v), body.replace(t, v)
        emp = re.sub(r"[^A-Za-z0-9]", "", s["emp"]) or re.sub(r"[^A-Za-z0-9]", "", s["email"].split("@")[0]) or "unknown"
        fname = f"aimissingdata{emp}_{ts}.txt"
        path = write_txt(SPECIAL_DIR, fname, to=f"{s['name'] or ''} <{s['email']}>".strip() if s["email"] else (s["name"] or ""),
                         cc="; ".join(sorted(s["cc"])), bcc="", subject=subject, body=body)
        first_path = first_path or path
        files.append({"name": fname, "kind": "special", "to": s["email"] or s["name"],
                      "accounts": len(s["accounts"])})
    return {"agent": "Follow Up on Missing Info", "used_ai": used_ai, "why": why, "folder": SPECIAL_DIR,
            "files": files, "preview": open(first_path, encoding="utf-8").read() if first_path else "",
            "no_spoc": no_spoc,
            "summary": f"{len(files)} email(s) drafted, one per SPOC with missing data for {m['label']}"
                       + (f"; {len(no_spoc)} account(s) skipped because they have no SPOC" if no_spoc else "") + "."}


# ---------------------------------------------------------------- agent 4: motivation (ISU top performers)
TOP_N = 5
LVL = {l: i for i, l in enumerate(["L0", "L1", "L2", "L3", "L4", "L5"])}


def progression(levels, months):
    """Facts about one account's derived monthly maturity over FY27 so far, or None if not at L2+ now."""
    db = H["db"]
    cur = levels.get(months[-1])
    if not cur or LVL[cur] < 2:
        return None
    start = next((levels.get(m) for m in months if levels.get(m)), None)
    first_month = next((m for m in months if levels.get(m)), months[0])
    start_lvl = levels.get(months[0])   # level at the start of FY27 (None = not yet assessed)
    reached = {}
    for tgt in ("L2", "L3"):
        if LVL[cur] >= LVL[tgt]:
            reached[tgt] = next((m for m in months if levels.get(m) and LVL[levels[m]] >= LVL[tgt]), None)
    since = next(m for m in months if levels.get(m) == cur and all(levels.get(x) == cur for x in months[months.index(m):]))
    gained = LVL[cur] - (LVL[start_lvl] if start_lvl else LVL[start] if start else 0)
    if start_lvl:
        story = f"{start_lvl} in {db.month_label(months[0])} to {cur} in {db.month_label(months[-1])}"
    else:
        story = f"first assessed at {start} in {db.month_label(first_month)}, now {cur}"
    return {"level": cur, "gained": gained, "since": since, "story": story,
            "reached": {k: db.month_label(v) for k, v in reached.items() if v}}


def agent_motivation():
    db = H["db"]
    months = db.fy_months()
    c = H["conn"]()
    try:
        mat = H["maturity_by_month"](c, months)
        rows = c.execute("""SELECT cu.id, cu.name, cu.spoc_name, cu.spoc_email, cu.spoc_emp_no,
                i.id isu_id, i.name isu, i.spoc_email isu_email, b.name bg
            FROM customer cu JOIN isu i ON i.id=cu.isu_id JOIN bg b ON b.id=i.bg_id ORDER BY b.id, i.id, cu.name""").fetchall()
    finally:
        c.close()
    m = month_info()
    by_isu = OrderedDict()
    for r in rows:
        by_isu.setdefault(r["isu_id"], []).append(r)

    plan, skipped = [], []   # plan: (isu rows, top list, recipients {key: spoc})
    for isu_rows in by_isu.values():
        isu = isu_rows[0]["isu"]
        scored = [(r, p) for r in isu_rows if (p := progression(mat.get(r["id"], {}), months))]
        scored.sort(key=lambda x: (-LVL[x[1]["level"]], -x[1]["gained"], x[1]["since"], x[0]["name"]))
        top = scored[:TOP_N]
        if not top:
            skipped.append(f"{isu}: no account at L2 or above yet")
            continue
        top_ids = {r["id"] for r, _ in top}
        top_spocs = {(r["spoc_emp_no"] or "").strip() or (r["spoc_email"] or "").strip().lower() for r, _ in top} - {""}
        recips = OrderedDict()
        for r in isu_rows:
            key = (r["spoc_emp_no"] or "").strip() or (r["spoc_email"] or "").strip().lower()
            if r["id"] in top_ids or not key or key in top_spocs:
                continue
            s = recips.setdefault(key, {"emp": (r["spoc_emp_no"] or "").strip(), "name": r["spoc_name"],
                                        "email": (r["spoc_email"] or "").strip(), "accounts": []})
            s["accounts"].append(r)
        if not recips:
            skipped.append(f"{isu}: all {len(isu_rows)} accounts are in the top {len(top)}, so no one else to motivate")
            continue
        plan.append((isu_rows, top, recips))

    tokens = ["{{FIRST_NAME}}", "{{ISU}}", "{{TOP_PERFORMERS}}", "{{YOUR_ACCOUNTS}}"]
    subj_t, body_t, why = (None, None, "no ISU had anyone to email") if not plan else ai_draft(
        "Write a motivating, upbeat email TEMPLATE to one AccountAI-SPOC in an ISU (Industry Service Unit). It "
        f"celebrates the ISU's top performing customer accounts on AI Service Autonomy maturity progression (levels "
        f"L0-L5; reaching L2 and L3 are the key milestones) as of {m['label']} in the {PORTAL}, and encourages the "
        "reader to move their own account(s) up next. It will be personalised by software, so use these "
        "placeholders exactly:\n"
        "- {{FIRST_NAME}} : the reader's first name (greeting)\n"
        "- {{ISU}} : the ISU name (also use it in the subject)\n"
        "- {{TOP_PERFORMERS}} : a pre-formatted list of the top accounts with their level and progression (own "
        "lines; do not restate its contents)\n"
        "- {{YOUR_ACCOUNTS}} : a pre-formatted list of the reader's accounts with current level and next milestone "
        "(own lines; do not restate its contents)\n"
        "Tone: recognition and friendly peer motivation, never shaming. Suggest practical next steps toward the next "
        "level: complete the AI workshop, keep the 30-60-90 plan items moving, and schedule a reassessment once "
        "progress is made, and mention they can learn from the top accounts' SPOCs. Mention they can update "
        f"progress in the portal or via its AI Chat. Sign off as: {sender()}, on behalf of the AI Synapse team. "
        "Body under 200 words excluding the lists.",
        required_tokens=tokens)
    used_ai = subj_t is not None
    if not used_ai:
        subj_t = "{{ISU}} AI Service Autonomy: celebrating our top accounts - your account can be next!"
        body_t = ("Dear {{FIRST_NAME}},\n\nGreat progress is happening in {{ISU}} on the AI Service Autonomy journey. "
                  f"As of {m['label']}, these accounts lead the ISU on L2 / L3 maturity progression:\n\n"
                  "{{TOP_PERFORMERS}}\n\nCongratulations to these teams. Here is where your account(s) stand today:\n\n"
                  "{{YOUR_ACCOUNTS}}\n\nA few steps that helped the top accounts move up:\n"
                  "- Complete the AI workshop with the customer\n- Keep your 30-60-90 plan items moving\n"
                  "- Schedule a reassessment once progress is made\n\nFeel free to reach out to the SPOCs of the top "
                  "accounts to learn what worked for them. You can update progress in the " + PORTAL +
                  " or simply describe it in its AI Chat.\n\nLet's make " + "{{ISU}}" + " the next success story!\n\n"
                  f"Best regards,\n{sender()}\nOn behalf of the AI Synapse team")

    ts = stamp()
    files, first_path, used_names = [], None, set()
    for isu_rows, top, recips in plan:
        isu = isu_rows[0]["isu"]
        top_txt = "\n".join(
            f"{i}. {r['name']} - {p['level']} (" + p["story"]
            + (f"; reached " + ", ".join(f"{k} in {v}" for k, v in p["reached"].items()) if p["reached"] else "") + ")"
            for i, (r, p) in enumerate(top, 1))
        isu_cc = (isu_rows[0]["isu_email"] or "").strip()
        for key, s in recips.items():
            acc = []
            for r in s["accounts"]:
                lvl = mat.get(r["id"], {}).get(months[-1])
                nxt = "L2" if not lvl or LVL[lvl] < 2 else "L3" if LVL[lvl] < 3 else f"L{LVL[lvl] + 1}"
                acc.append(f"- {r['name']}: " + (f"currently {lvl}" if lvl else "not assessed yet") + f"; next milestone {nxt}")
            fill = {"{{FIRST_NAME}}": first_name(s["name"], s["email"]), "{{ISU}}": isu,
                    "{{TOP_PERFORMERS}}": top_txt, "{{YOUR_ACCOUNTS}}": "\n".join(acc)}
            subject, body = subj_t, body_t
            for t, v in fill.items():
                subject, body = subject.replace(t, v), body.replace(t, v)
            emp = re.sub(r"[^A-Za-z0-9]", "", s["emp"]) or re.sub(r"[^A-Za-z0-9]", "", s["email"].split("@")[0]) or "unknown"
            fname = f"motivation{emp}_{ts}.txt"
            n = 2
            while fname in used_names:   # same SPOC in two ISUs: keep both files
                fname, n = f"motivation{emp}_{ts}_{n}.txt", n + 1
            used_names.add(fname)
            path = write_txt(MOTIVATION_DIR, fname,
                             to=f"{s['name'] or ''} <{s['email']}>".strip() if s["email"] else (s["name"] or ""),
                             cc=isu_cc, bcc="", subject=subject, body=body)
            first_path = first_path or path
            files.append({"name": fname, "kind": "motivation", "to": s["email"] or s["name"],
                          "accounts": f"{isu}: " + ", ".join(r["name"] for r in s["accounts"])})
    return {"agent": "Motivation Agent", "used_ai": used_ai if plan else None, "why": why if plan else None,
            "folder": MOTIVATION_DIR, "files": files,
            "preview": open(first_path, encoding="utf-8").read() if first_path else "",
            "skipped": skipped,
            "summary": f"{len(files)} motivation email(s) drafted across {len(plan)} ISU(s): each goes to a customer SPOC "
                       f"outside their ISU's top {TOP_N} on L2 / L3 progression (as of {m['label']})."
                       + (f" {len(skipped)} ISU(s) skipped." if skipped else "")}


# ---------------------------------------------------------------- routes
@bp.route("/agents", methods=["GET", "POST"])
def page():
    _admin()
    result = None
    if request.method == "POST":
        action = request.form.get("agent")
        if action == "reminder_all":
            result = agent_general()
        elif action == "missing_info":
            result = agent_missing()
        elif action == "motivation":
            result = agent_motivation()
        elif action == "sync_crm":
            result = {"agent": "Sync CRM Data", "summary": "No action yet: the CRM sync is not configured. "
                      "This agent will be set up once the CRM details are provided.", "files": [], "used_ai": None}
        else:
            abort(400)
    recent = {}
    for kind, folder in (("general", GENERAL_DIR), ("special", SPECIAL_DIR), ("motivation", MOTIVATION_DIR)):
        try:
            names = sorted((f for f in os.listdir(folder) if f.endswith(".txt")),
                           key=lambda f: os.path.getmtime(os.path.join(folder, f)), reverse=True)
        except FileNotFoundError:
            names = []
        recent[kind] = names[:8]
    return render_template("agents.html", result=result, recent=recent, general_dir=GENERAL_DIR,
                           special_dir=SPECIAL_DIR, motivation_dir=MOTIVATION_DIR, ai_ready=bool(H["api_key"]()),
                           month=month_info())


@bp.route("/agents/file/<kind>/<name>")
def view_file(kind, name):
    _admin()
    folder = {"general": GENERAL_DIR, "special": SPECIAL_DIR, "motivation": MOTIVATION_DIR}.get(kind) or abort(404)
    if not re.fullmatch(r"[A-Za-z0-9_.-]+\.txt", name):   # file names only, no paths
        abort(404)
    path = os.path.join(folder, name)
    if not os.path.isfile(path):
        abort(404)
    with open(path, encoding="utf-8") as f:
        text = f.read()
    return render_template("agents.html", result=None, recent=None, view={"name": name, "folder": folder, "text": text},
                           general_dir=GENERAL_DIR, special_dir=SPECIAL_DIR, motivation_dir=MOTIVATION_DIR,
                           ai_ready=bool(H["api_key"]()), month=month_info())
