"""AI chat window: regular users add new records by chatting with Claude.

How it works
* Claude (Anthropic API) talks with the user and gathers the details for one of the five sections:
  AI Service Autonomy, Key Deals, Customer Touchpoints, Distinguished Engineers, Asset Contribution.
* Claude never writes to the database. Its tools only create a DRAFT, which the page shows as a card with
  Confirm / Cancel buttons. Only the user's Confirm click saves it, after the same checks as the forms
  (required fields, pick-list values, unique employee number) and only for the user's own customers.
* Conversations are kept in server memory per user (lost when the server restarts; "New chat" clears them).

Configuration: the Anthropic API key comes from the ANTHROPIC_API_KEY environment variable, or from the
file anthropic_api_key.txt next to this file (keep that file private).
"""
import os
import re
import threading
import uuid
from datetime import date

from flask import Blueprint, abort, g, jsonify, render_template, request, session

MODEL = "claude-opus-5-5"
KEY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "anthropic_api_key.txt")
MAX_TOOL_ROUNDS = 8
MONTH_RE = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
DATE_RE = re.compile(r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$")

bp = Blueprint("chat", __name__)
H = {}                      # helpers injected from app.py by init()
_chats = {}                 # (username, context) -> {"messages": [...], "drafts": {id: draft}}
# Chat contexts: "all" = the full AI Chat page; "autonomy" = the panel on the AI Service Autonomy screen
# (its own conversation, limited to autonomy data).
CONTEXTS = ("all", "autonomy", "deals", "touchpoints", "engineers", "assets")   # one panel per data screen
_lock = threading.Lock()
_client = None


# ---------------------------------------------------------------- setup
def init(app, **helpers):
    H.update(helpers)
    app.register_blueprint(bp)


def api_key():
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if not key and os.path.exists(KEY_FILE):
        with open(KEY_FILE, encoding="utf-8-sig") as f:
            key = f.read().strip()
        if "=" in key.split("sk-ant-")[0]:   # accept "ANTHROPIC_API_KEY=sk-ant-..." as well as the bare key
            key = key.split("=", 1)[1].strip()
        key = key.strip("\"'").strip()
    return key


def client():
    global _client
    if _client is None:
        import anthropic
        _client = anthropic.Anthropic(api_key=api_key())
    return _client


def read_ctx():
    ctx = request.args.get("ctx") or (request.get_json(silent=True) or {}).get("ctx") or "all"
    return ctx if ctx in CONTEXTS else abort(404)


def chat_state(ctx="all"):
    with _lock:
        return _chats.setdefault((session["user"], ctx), {"messages": [], "drafts": {}})


# ---------------------------------------------------------------- tool definitions
# Tool inputs are NOT schema-strict: the forms have more optional fields than strict mode allows, and every
# draft is validated server-side (validate_entity / validate_autonomy) before it is shown and again on Confirm.
OPTIONAL = "_optional"


def _nullable(schema):
    """Mark a field optional (left out of "required"; the model omits it when the user didn't give it)."""
    return dict(schema, **{OPTIONAL: True})


def _obj(props, desc):
    required = [k for k, v in props.items() if not v.get(OPTIONAL)]
    clean = {k: {kk: vv for kk, vv in v.items() if kk != OPTIONAL} for k, v in props.items()}
    return {"type": "object", "description": desc, "properties": clean, "required": required,
            "additionalProperties": False}


def section_fields(c):
    """{section: [(field, label, kind, options, required)]} for the four record sections (live lookups)."""
    out = {}
    for name, cfg in H["ENTITIES"].items():
        out[name] = [(f, lbl, kind, H["options_for"](c, opts) if opts else None, f in H["REQUIRED"])
                     for f, lbl, kind, opts in cfg["fields"]]
    return out


def field_schema(label, kind, options, required):
    if options:
        s = {"type": "string", "enum": list(options), "description": label}
    elif kind == "number":
        s = {"type": "number", "description": label}
    elif kind == "month":
        s = {"type": "string", "description": f"{label} (YYYY-MM)"}
    elif kind == "date":
        s = {"type": "string", "description": f"{label} (YYYY-MM-DD)"}
    else:
        s = {"type": "string", "description": label}
    return s if required else _nullable(s)


def chat_sections(ctx):
    """Record sections (deals / touchpoints / engineers / assets) a chat context may work with."""
    if ctx == "all":
        return list(H["ENTITIES"])
    return [ctx] if ctx in H["ENTITIES"] else []


def tools(c, ctx="all"):
    t = [{
        "name": "list_my_customers",
        "description": "List the customers (accounts) this user may add data for, with their ids, ISU and BG. "
                       "Call this before proposing a record so you use the right customer_id.",
        "input_schema": _obj({}, "No input."),
    }]
    secs = chat_sections(ctx)
    titles = {"deals": "Key Deals", "touchpoints": "Customer Touchpoints", "engineers": "Distinguished Engineers",
              "assets": "Asset Contribution"}
    fields_by = section_fields(c)
    if secs:
        t.append({
            "name": "list_records",
            "description": "List the user's EXISTING records of a section (with record ids and all fields), "
                           "optionally for one customer. Use it to answer questions about existing data and to find "
                           "the record_id before proposing an update.",
            "input_schema": _obj({
                "section": {"type": "string", "enum": secs, "description": "Section"},
                "customer_id": _nullable({"type": "integer", "description": "Only this customer (optional)"}),
            }, "Records to list"),
        })
    for name in secs:
        fields = fields_by[name]
        props = {"customer_id": {"type": "integer", "description": "Customer id from list_my_customers"}}
        for f, lbl, kind, options, req in fields:
            props[f] = field_schema(lbl, kind, options, req)
        t.append({
            "name": f"propose_{name}",
            "description": f"Create a DRAFT new {titles[name]} record for the user to review. Nothing is saved until "
                           f"the user clicks Confirm on the draft card. Leave out details the user did not give.",
            "input_schema": _obj(props, f"New {titles[name]} record"),
        })
        upd = {"record_id": {"type": "integer", "description": "Record id from list_records"}}
        for f, lbl, kind, options, req in fields:
            upd[f] = field_schema(lbl, kind, options, False)
        t.append({
            "name": f"update_{name}",
            "description": f"Create a DRAFT change to an EXISTING {titles[name]} record. Give record_id and ONLY the "
                           f"fields to change; all other fields keep their values. Nothing is saved until the user "
                           f"clicks Confirm.",
            "input_schema": _obj(upd, f"Change to a {titles[name]} record"),
        })
    if ctx not in ("all", "autonomy"):
        return t
    t += [{
        "name": "get_autonomy_details",
        "description": "Show one customer's current AI Service Autonomy data: profile, assessments, derived current "
                       "maturity level and 30-60-90 plan items (with their plan_item_id). Use it to answer questions "
                       "about the account and before proposing a plan status change.",
        "input_schema": _obj({"customer_id": {"type": "integer", "description": "Customer id from list_my_customers"}},
                             "Customer to look up"),
    }, {
        "name": "propose_plan_status",
        "description": "Create a DRAFT change of an EXISTING 30-60-90 plan item's status (get its plan_item_id from "
                       "get_autonomy_details). Nothing is saved until the user clicks Confirm.",
        "input_schema": _obj({
            "plan_item_id": {"type": "integer", "description": "plan_item_id from get_autonomy_details"},
            "status": {"type": "string", "enum": H["db"].PLAN_STATUSES, "description": "New status"},
        }, "Plan item status change"),
    }]
    db = H["db"]
    t.append({
        "name": "propose_autonomy",
        "description": "Create a DRAFT AI Service Autonomy capture for one customer: any of profile fields, one "
                       "maturity assessment, one 30-60-90 plan item. Leave out parts not given. Nothing is saved "
                       "until the user clicks Confirm.",
        "input_schema": _obj({
            "customer_id": {"type": "integer", "description": "Customer id from list_my_customers"},
            "workshop_completed": _nullable({"type": "string", "enum": ["Y", "N"], "description": "AI workshop completed"}),
            "mega_ai_journey": _nullable({"type": "string", "enum": ["Y", "N"], "description": "Mega AI Journey"}),
            "headcount_band": _nullable({"type": "string", "enum": db.HEADCOUNT_BANDS, "description": "Headcount band"}),
            "target_level": _nullable({"type": "string", "enum": db.LEVELS, "description": "Target maturity level"}),
            "target_quarter": _nullable({"type": "string", "description": "Target quarter, e.g. Q4 FY27"}),
            "assessment_type": _nullable({"type": "string", "enum": ["Baseline", "Reassessment"], "description": "Assessment type"}),
            "assessment_level": _nullable({"type": "string", "enum": db.LEVELS, "description": "Assessed level"}),
            "assessment_date": _nullable({"type": "string", "description": "Assessment date (YYYY-MM-DD)"}),
            "assessment_score": _nullable({"type": "number", "description": "Assessment score 0-100"}),
            "plan_item": _nullable({"type": "string", "description": "30-60-90 plan item description"}),
            "plan_owner": _nullable({"type": "string", "description": "Plan item owner"}),
            "plan_due_date": _nullable({"type": "string", "description": "Plan item due date (YYYY-MM-DD)"}),
            "plan_status": _nullable({"type": "string", "enum": db.PLAN_STATUSES, "description": "Plan item status"}),
        }, "New AI Service Autonomy capture"),
    })
    return t


SECTION_NOTES = {
    "deals": "Deal value is in USD millions. When status is Won, ask for the win team; when Lost, ask what did not "
             "resonate / the reason for failure.",
    "touchpoints": "Type of engagement is required. Each touchpoint is one engagement in a reporting month.",
    "engineers": "Associate name and employee number are required; the employee number must be unique. Month added "
                 "is when the engineer joined the account (headcount is cumulative from that month).",
    "assets": "Asset name is required. Number of assets is a whole number. Core platform is Y or N.",
}


def focus_line(focus):
    if not focus:
        return "No specific account is open on the screen right now.\n"
    line = (f"The account the user is working on is customer id {focus['id']}: {focus['name']} (ISU {focus['isu']}, "
            f"BG {focus['bg']}). Assume the user means this account unless they name another.\n")
    if focus.get("record_id"):
        line += f"The user has record id {focus['record_id']} of this section open in the edit form.\n"
    return line


def user_line():
    return (f"Signed-in user: {session.get('full_name') or session['user']} (user ID {session['user']}). "
            f"Today's date: {date.today().isoformat()} (FY27 runs April 2026 to March 2027).")


def system_prompt(ctx="all", focus=None):
    if ctx in H["ENTITIES"]:
        title = SECTION_TITLES[ctx]
        return (
            f"You are the AI Synapse (AIDASH) assistant built into the {title} screen. You help the signed-in user "
            f"keep {title} data up to date for their own customer accounts:\n"
            f"- add a NEW record (propose_{ctx})\n"
            f"- change an EXISTING record (list_records to find its record_id, then update_{ctx} with only the fields "
            f"that change)\n"
            f"- answer questions about their existing {title} records (list_records)\n"
            f"{SECTION_NOTES[ctx]}\n\n"
            "How to work:\n"
            "- Use list_my_customers for valid customer ids; the user can only change their own customers. If a name "
            "or record is ambiguous, ask.\n"
            "- Ask briefly for missing essentials (one short message, not a questionnaire). Optional fields may stay "
            "empty. Convert to the right formats: months as YYYY-MM, dates as YYYY-MM-DD, pick-list values exactly as "
            "in the tool schema. Never invent facts the user did not give.\n"
            "- Changes are only drafts shown as cards; the user saves by clicking Confirm. Never say something is "
            "saved until you see a note that the user confirmed it.\n"
            "- If a tool returns an error, explain it plainly and ask for the fix.\n"
            f"- You cannot delete records (the user can use Delete in the records list) and you cannot change other "
            f"sections; point the user to that section's screen or the AI Chat page. Decline unrelated requests.\n"
            "- Keep replies short and friendly. Plain text; simple '-' bullets are fine.\n\n"
            + focus_line(focus) + user_line()
        )
    if ctx == "autonomy":
        return (
            "You are the AI Synapse (AIDASH) assistant built into the AI Service Autonomy screen. You help the "
            "signed-in user keep AI Service Autonomy data up to date for their own customer accounts:\n"
            "- profile: workshop completed, Mega AI Journey, headcount band, target level, target quarter "
            "(propose_autonomy; given fields fill in or overwrite, other fields stay as they are)\n"
            "- a new maturity assessment (Baseline or Reassessment, level L0-L5, date, optional score 0-100). Monthly "
            "maturity is derived from the latest assessment on or before each month end, so a new assessment is how "
            "the level changes.\n"
            "- a new 30-60-90 plan item (description, owner, due date, status)\n"
            "- the status of an existing plan item (propose_plan_status)\n\n"
            "How to work:\n"
            "- Use list_my_customers for valid customer ids; the user can only change their own customers. Use "
            "get_autonomy_details to see the account's current data and to answer questions about it.\n"
            "- Ask briefly for missing essentials. Convert dates to YYYY-MM-DD and use pick-list values exactly as in "
            "the tool schema. Never invent facts the user did not give.\n"
            "- Changes are only drafts shown as cards; the user saves by clicking Confirm. Never say something is "
            "saved until you see a note that the user confirmed it.\n"
            "- You cannot delete assessments or plan items, or change other sections (deals, touchpoints, engineers, "
            "assets); point the user to the AI Chat page or the section pages for those. Decline unrelated requests.\n"
            "- Keep replies short and friendly. Plain text; simple '-' bullets are fine.\n\n"
            + focus_line(focus) + user_line()
        )
    return (
        "You are the AI Synapse (AIDASH) data-entry assistant for TCS account teams. You help the signed-in user add "
        "NEW records for their own customer accounts in five sections: AI Service Autonomy (profile, maturity "
        "assessment, 30-60-90 plan item), Key Deals, Customer Touchpoints, Distinguished Engineers and Asset "
        "Contribution.\n\n"
        "How to work:\n"
        "- Find out which section and customer the user means. Call list_my_customers to get valid customer ids; the "
        "user can only add data for those customers. If a name is ambiguous, ask.\n"
        "- Ask briefly for the important details that are missing (one short message, not a long questionnaire). "
        "Required fields must be filled; other fields may stay empty if the user doesn't know them.\n"
        "- Convert what the user says into the right formats: months as YYYY-MM, dates as YYYY-MM-DD, deal value in "
        "USD millions, and pick-list values exactly as listed in the tool schema. Never invent facts the user did "
        "not give.\n"
        "- When you have enough, call the matching propose_* tool. It only creates a draft card; the user saves it "
        "by clicking Confirm. Never say a record is saved until you see a note that the user confirmed it.\n"
        "- If a tool returns an error, explain it plainly and ask for the fix.\n"
        "- You can also change existing data: a Key Deals / Touchpoints / Engineers / Assets record (list_records, "
        "then update_<section> with only the fields that change) and a 30-60-90 plan item's status "
        "(get_autonomy_details, then propose_plan_status). You cannot delete records or change the organisation "
        "hierarchy; point the user to the pages for that. Politely decline requests unrelated to AIDASH data entry.\n"
        "- Keep replies short and friendly. Plain text; simple '-' bullets are fine.\n\n"
        f"Signed-in user: {session.get('full_name') or session['user']} (user ID {session['user']}). "
        f"Today's date: {date.today().isoformat()} (FY27 runs April 2026 to March 2027)."
    )


# ---------------------------------------------------------------- validation (same rules as the forms)
def _clean(v):
    if isinstance(v, str):
        v = v.strip()
        return v or None
    return v


def check_customer(c, cid):
    if not isinstance(cid, int) or not c.execute("SELECT 1 FROM customer WHERE id=?", (cid,)).fetchone():
        return "Unknown customer id. Call list_my_customers and use one of those ids."
    if not H["customer_in_scope"](c, cid):
        return "That customer is not one of this user's customers; the user can only add data for their own customers."
    return None


def validate_entity(c, name, data, record_id=None, keep=None):
    """(clean values, errors) for a Key Deals / Touchpoints / Engineers / Assets record.
    For an update: record_id excludes the record itself from the unique check, and `keep` holds its current values,
    which stay acceptable even if a pick-list value has since been removed from the lookups."""
    errors, vals = [], {}
    keep = keep or {}
    err = check_customer(c, data.get("customer_id"))
    if err:
        errors.append(err)
    for f, lbl, kind, options, req in section_fields(c)[name]:
        v = _clean(data.get(f))
        if v is not None and v == keep.get(f):
            vals[f] = v   # unchanged value of an existing record
            continue
        if v is None:
            if req:
                errors.append(f"{lbl} is required")
        elif options and v not in options:
            errors.append(f"{lbl} must be one of: {', '.join(options)}")
        elif kind == "month" and not MONTH_RE.match(str(v)):
            errors.append(f"{lbl} must be a month as YYYY-MM")
        elif kind == "date" and not DATE_RE.match(str(v)):
            errors.append(f"{lbl} must be a date as YYYY-MM-DD")
        elif kind == "number":
            try:
                v = float(v)
                if v < 0:
                    raise ValueError
                if f == "asset_count":
                    v = int(v)
            except (TypeError, ValueError):
                errors.append(f"{lbl} must be a non-negative number")
        vals[f] = v
    if name == "engineers" and vals.get("employee_number") and c.execute(
            "SELECT 1 FROM engineer WHERE employee_number=? AND id<>?",
            (str(vals["employee_number"]), record_id or 0)).fetchone():
        errors.append(f"Employee number {vals['employee_number']} already exists; it must be unique")
    return vals, errors


def record_row(c, name, rid):
    try:
        rid = int(rid)
    except (TypeError, ValueError):
        return None
    return c.execute(f"SELECT * FROM {H['ENTITIES'][name]['table']} WHERE id=?", (rid,)).fetchone()


def validate_update(c, name, record_id, changes):
    """(merged values, {field: (old, new)}, errors) for a change to an existing record of the user's."""
    old = record_row(c, name, record_id)
    if not old:
        return {}, {}, [f"Unknown record_id. Call list_records for {SECTION_TITLES[name]} and use one of its ids."]
    if not H["customer_in_scope"](c, old["customer_id"]):
        return {}, {}, ["That record belongs to a customer that is not one of this user's customers."]
    fields = [f for f, *_ in H["ENTITIES"][name]["fields"]]
    keep = {f: old[f] for f in fields}
    given = {f: changes[f] for f in fields if f in changes and changes[f] is not None and changes[f] != ""}
    merged = {"customer_id": old["customer_id"], **keep, **given}
    vals, errors = validate_entity(c, name, merged, record_id=old["id"], keep=keep)
    diff = {f: (old[f], vals.get(f)) for f in given if vals.get(f) != old[f]}
    if not errors and not diff:
        errors.append("no field would change; tell me what to change")
    return vals, diff, errors


def list_records(c, name, cid=None):
    cfg = H["ENTITIES"][name]
    rows = [r for r in H["scoped_records"](c, name, "", "", "", None)
            if H["customer_in_scope"](c, r["customer_id"]) and (not cid or r["customer_id"] == cid)]
    if not rows:
        return f"No {cfg['title']} records" + (" for that customer." if cid else " for this user's customers.")
    labels = [(f, lbl) for f, lbl, *_ in cfg["fields"]]
    out = [f"{len(rows)} {cfg['title']} record(s), newest first:"]
    for r in rows[:60]:
        vals = "; ".join(f"{lbl}: {r[f]:g}" if isinstance(r[f], float) else f"{lbl}: {r[f]}"
                         for f, lbl in labels if r[f] not in (None, ""))
        out.append(f"- record_id {r['id']} | customer {r['customer']} (id {r['customer_id']}) | {vals}")
    if len(rows) > 60:
        out.append(f"(showing 60 of {len(rows)}; ask for one customer to narrow it down)")
    return "\n".join(out)


AUT_PROFILE = ["workshop_completed", "mega_ai_journey", "headcount_band", "target_level", "target_quarter"]


def validate_autonomy(c, data):
    db = H["db"]
    errors = []
    err = check_customer(c, data.get("customer_id"))
    if err:
        errors.append(err)
    v = {k: _clean(data.get(k)) for k in data if k != "customer_id"}
    a_any = any(v.get(k) is not None for k in ("assessment_type", "assessment_level", "assessment_date", "assessment_score"))
    if a_any and not (v.get("assessment_type") in ("Baseline", "Reassessment") and v.get("assessment_level") in db.LEVELS
                      and v.get("assessment_date")):
        errors.append("an assessment needs type, level and date")
    for k in ("assessment_date", "plan_due_date"):
        if v.get(k) and not DATE_RE.match(str(v[k])):
            errors.append(f"{k.replace('_', ' ')} must be YYYY-MM-DD")
    if v.get("assessment_score") is not None:
        try:
            if not 0 <= float(v["assessment_score"]) <= 100:
                raise ValueError
        except (TypeError, ValueError):
            errors.append("assessment score must be between 0 and 100")
    if not v.get("plan_item") and (v.get("plan_owner") or v.get("plan_due_date")):
        errors.append("a plan item needs its description")
    if not errors and not any(v.get(k) for k in AUT_PROFILE) and not a_any and not v.get("plan_item"):
        errors.append("give at least one profile field, an assessment or a plan item")
    return v, errors


def plan_item_row(c, pid):
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return None
    return c.execute("SELECT * FROM plan_item WHERE id=?", (pid,)).fetchone()


def validate_plan_status(c, data):
    """(clean values, errors) for a status change of an existing plan item."""
    p = plan_item_row(c, data.get("plan_item_id"))
    if not p:
        return {}, ["Unknown plan_item_id. Call get_autonomy_details and use one of its plan_item_id values."]
    errors = []
    err = check_customer(c, p["customer_id"])
    if err:
        errors.append(err)
    status = _clean(data.get("status"))
    if status not in H["db"].PLAN_STATUSES:
        errors.append("status must be one of: " + ", ".join(H["db"].PLAN_STATUSES))
    elif status == p["status"]:
        errors.append(f"the plan item is already '{status}'")
    return {"plan_item_id": p["id"], "plan_item": p["item"], "old_status": p["status"] or "", "status": status}, errors


def autonomy_details(c, cid):
    """Readable summary of one customer's AI Service Autonomy data (for the model)."""
    err = check_customer(c, cid)
    if err:
        return err, True
    cu = c.execute("""SELECT cu.name, i.name isu, b.name bg FROM customer cu JOIN isu i ON i.id=cu.isu_id
        JOIN bg b ON b.id=i.bg_id WHERE cu.id=?""", (cid,)).fetchone()
    p = c.execute("SELECT * FROM autonomy WHERE customer_id=?", (cid,)).fetchone()
    lines = [f"Customer id {cid}: {cu['name']} (ISU {cu['isu']}, BG {cu['bg']})"]
    if p:
        lines.append("Profile: " + "; ".join(f"{k.replace('_', ' ')}={p[k] or '(blank)'}" for k in AUT_PROFILE))
    else:
        lines.append("Profile: none yet")
    today = date.today().isoformat()
    cur = c.execute("""SELECT level, assessment_date FROM assessment WHERE customer_id=? AND assessment_date<=?
        ORDER BY assessment_date DESC, id DESC LIMIT 1""", (cid, today)).fetchone()
    lines.append(f"Current maturity: {cur['level']} (from assessment of {cur['assessment_date']})" if cur
                 else "Current maturity: not assessed yet")
    rows = c.execute("SELECT * FROM assessment WHERE customer_id=? ORDER BY assessment_date", (cid,)).fetchall()
    lines.append("Assessments: " + ("; ".join(
        f"{r['assessment_date']} {r['type']} {r['level']}" + (f" (score {r['score']:g})" if r["score"] is not None else "")
        for r in rows) if rows else "none"))
    rows = c.execute("SELECT * FROM plan_item WHERE customer_id=? ORDER BY due_date", (cid,)).fetchall()
    lines.append("30-60-90 plan items:" if rows else "30-60-90 plan items: none")
    for r in rows:
        lines.append(f"- plan_item_id {r['id']}: {r['item']} | owner {r['owner'] or '(none)'} | due "
                     f"{r['due_date'] or '(none)'} | status {r['status'] or '(none)'}")
    return "\n".join(lines), False


def validate_draft(c, d):
    if d.get("mode") == "update":
        return validate_update(c, d["section"], d["record_id"], d["changes"])[2]
    data = {"customer_id": d["customer_id"], **d["values"]}
    if d["section"] == "autonomy":
        return validate_autonomy(c, data)[1]
    if d["section"] == "plan_status":
        return validate_plan_status(c, d["values"])[1]
    return validate_entity(c, d["section"], data)[1]


# ---------------------------------------------------------------- saving (only after the user confirms)
def save_draft(c, d):
    """Write a confirmed draft. Returns a short description of what was saved."""
    cid = d["customer_id"]
    if d.get("mode") == "update":   # only the changed fields; re-checked against the record as it is now
        cfg = H["ENTITIES"][d["section"]]
        vals, diff, errors = validate_update(c, d["section"], d["record_id"], d["changes"])
        if errors:
            raise ValueError("; ".join(errors))
        c.execute(f"UPDATE {cfg['table']} SET " + ", ".join(f"{f}=?" for f in diff) + " WHERE id=?",
                  [vals[f] for f in diff] + [d["record_id"]])
        c.commit()
        return f"{cfg['title']} record #{d['record_id']} updated ({', '.join(d['labels'].get(f, f) for f in diff)})"
    if d["section"] == "plan_status":
        v = d["values"]
        c.execute("UPDATE plan_item SET status=? WHERE id=?", (v["status"], v["plan_item_id"]))
        c.commit()
        return f"plan item '{v['plan_item']}' set to {v['status']}"
    if d["section"] == "autonomy":
        v, done = d["values"], []
        prof = {k: v.get(k) for k in AUT_PROFILE}
        if any(prof.values()):
            if c.execute("SELECT 1 FROM autonomy WHERE customer_id=?", (cid,)).fetchone():
                sets = {k: x for k, x in prof.items() if x}   # fill in given fields only, never blank existing ones
                c.execute("UPDATE autonomy SET " + ", ".join(f"{k}=?" for k in sets) + " WHERE customer_id=?",
                          (*sets.values(), cid))
                done.append("profile updated")
            else:
                c.execute("INSERT INTO autonomy(customer_id, " + ", ".join(AUT_PROFILE) + ") VALUES (?,?,?,?,?,?)",
                          (cid, *prof.values()))
                done.append("profile created")
        if v.get("assessment_level"):
            c.execute("INSERT INTO assessment(customer_id, type, score, level, assessment_date) VALUES (?,?,?,?,?)",
                      (cid, v["assessment_type"], v.get("assessment_score"), v["assessment_level"], v["assessment_date"]))
            done.append("assessment added")
        if v.get("plan_item"):
            c.execute("INSERT INTO plan_item(customer_id, item, owner, due_date, status) VALUES (?,?,?,?,?)",
                      (cid, v["plan_item"], v.get("plan_owner") or "", v.get("plan_due_date"),
                       v.get("plan_status") or "Not started"))
            done.append("plan item added")
        c.commit()
        return "AI Service Autonomy: " + ", ".join(done)
    cfg = H["ENTITIES"][d["section"]]
    cols = ["customer_id"] + list(d["values"])
    cur = c.execute(f"INSERT INTO {cfg['table']}({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
                    [cid, *d["values"].values()])
    c.commit()
    return f"{cfg['title']} record #{cur.lastrowid}"


# ---------------------------------------------------------------- tool execution
DRAFTED = ("Draft {} is now shown to the user as a card with Confirm / Cancel buttons. It is NOT saved yet. Tell the "
           "user to check it and click Confirm.")


def run_tool(c, st, name, data, new_drafts, ctx="all"):
    if name not in {t["name"] for t in tools(c, ctx)}:   # each screen's chat only has its own section's tools
        return "That isn't available in this chat; it only handles " + (
            SECTION_TITLES.get(ctx, "this screen's") + " data. Point the user to the right screen or the AI Chat page."), True
    if name == "list_records":
        sec = data.get("section")
        try:
            cid = int(data["customer_id"]) if data.get("customer_id") not in (None, "") else None
        except (TypeError, ValueError):
            return "customer_id must be a number from list_my_customers.", True
        if cid and check_customer(c, cid):
            return check_customer(c, cid), True
        return list_records(c, sec, cid), False
    if name.startswith("update_"):
        sec = name[len("update_"):]
        vals, diff, errors = validate_update(c, sec, data.get("record_id"), data)
        if errors:
            return "Not drafted: " + "; ".join(errors) + ".", True
        old = record_row(c, sec, data["record_id"])
        cust = c.execute("SELECT name FROM customer WHERE id=?", (old["customer_id"],)).fetchone()["name"]
        labels = {f: lbl for f, lbl, *_ in H["ENTITIES"][sec]["fields"]}
        d = {"id": uuid.uuid4().hex[:8], "section": sec, "mode": "update", "record_id": old["id"],
             "customer_id": old["customer_id"], "customer": cust, "changes": {f: vals[f] for f in diff},
             "values": vals, "diff": diff, "labels": labels, "status": "pending"}
        st["drafts"][d["id"]] = d
        new_drafts.append(draft_view(d))
        return DRAFTED.format(d["id"]), False
    if name == "get_autonomy_details":
        try:
            cid = int(data.get("customer_id"))
        except (TypeError, ValueError):
            return "customer_id must be a number from list_my_customers.", True
        return autonomy_details(c, cid)
    if name == "propose_plan_status":
        vals, errors = validate_plan_status(c, data)
        if errors:
            return "Not drafted: " + "; ".join(errors) + ".", True
        cid = plan_item_row(c, vals["plan_item_id"])["customer_id"]
        cust = c.execute("SELECT name FROM customer WHERE id=?", (cid,)).fetchone()["name"]
        d = {"id": uuid.uuid4().hex[:8], "section": "plan_status", "customer_id": cid, "customer": cust,
             "values": vals, "status": "pending"}
        st["drafts"][d["id"]] = d
        new_drafts.append(draft_view(d))
        return (f"Draft {d['id']} is now shown to the user as a card with Confirm / Cancel buttons. It is NOT saved "
                f"yet. Tell the user to check it and click Confirm."), False
    if name == "list_my_customers":
        rows = H["scoped_customers"](c, "", "")
        if not rows:
            return "This user has no customers assigned (an admin sets the customer's AccountAI-SPOC emp no to the " \
                   "user's ID). They cannot add data yet.", False
        return "\n".join(f"id {r['id']}: {r['name']} (ISU {r['isu']}, BG {r['bg']})" for r in rows), False
    if name.startswith("propose_"):
        section = name[len("propose_"):]
        try:   # schemas aren't strict, so accept "131" as well as 131
            data["customer_id"] = int(data.get("customer_id"))
        except (TypeError, ValueError):
            pass
        if section == "autonomy":
            vals, errors = validate_autonomy(c, data)
        elif section in H["ENTITIES"]:
            vals, errors = validate_entity(c, section, data)
        else:
            return f"Unknown tool {name}", True
        if errors:
            return "Not drafted: " + "; ".join(errors) + ".", True
        cust = c.execute("SELECT name FROM customer WHERE id=?", (data["customer_id"],)).fetchone()["name"]
        d = {"id": uuid.uuid4().hex[:8], "section": section, "customer_id": data["customer_id"], "customer": cust,
             "values": vals, "status": "pending"}
        st["drafts"][d["id"]] = d
        new_drafts.append(draft_view(d))
        return (f"Draft {d['id']} is now shown to the user as a card with Confirm / Cancel buttons. It is NOT saved "
                f"yet. Tell the user to check it and click Confirm."), False
    return f"Unknown tool {name}", True


SECTION_TITLES = {"autonomy": "AI Service Autonomy", "deals": "Key Deals", "touchpoints": "Customer Touchpoints",
                  "engineers": "Distinguished Engineers", "assets": "Asset Contribution",
                  "plan_status": "30-60-90 plan item status"}


def _show(v):
    if v in (None, ""):
        return "(blank)"
    return f"{v:g}" if isinstance(v, float) else str(v)


def draft_view(d):
    if d.get("mode") == "update":
        rows = [["Customer", d["customer"]], ["Record", f"#{d['record_id']}"]]
        rows += [[d["labels"].get(f, f), f"{_show(o)} → {_show(n)}"] for f, (o, n) in d["diff"].items()]
        return {"id": d["id"], "title": f"Update {SECTION_TITLES[d['section']]} record", "rows": rows,
                "status": d["status"], "customer_id": d["customer_id"]}
    if d["section"] == "plan_status":
        v = d["values"]
        rows = [["Customer", d["customer"]], ["Plan item", v["plan_item"]],
                ["Status", f"{v['old_status'] or '(none)'} → {v['status']}"]]
        return {"id": d["id"], "title": SECTION_TITLES["plan_status"], "rows": rows, "status": d["status"],
                "customer_id": d["customer_id"]}
    if d["section"] == "autonomy":
        labels = {"workshop_completed": "Workshop completed", "mega_ai_journey": "Mega AI Journey",
                  "headcount_band": "Headcount band", "target_level": "Target level", "target_quarter": "Target quarter",
                  "assessment_type": "Assessment type", "assessment_level": "Assessment level",
                  "assessment_date": "Assessment date", "assessment_score": "Assessment score",
                  "plan_item": "Plan item", "plan_owner": "Plan owner", "plan_due_date": "Plan due date",
                  "plan_status": "Plan status"}
    else:
        labels = {f: lbl for f, lbl, *_ in H["ENTITIES"][d["section"]]["fields"]}
    rows = [["Customer", d["customer"]]] + [[labels.get(k, k), v] for k, v in d["values"].items() if v not in (None, "")]
    return {"id": d["id"], "title": SECTION_TITLES[d["section"]], "rows": rows, "status": d["status"],
            "customer_id": d["customer_id"]}


# ---------------------------------------------------------------- Claude call
def ask_claude(c, st, ctx="all", focus=None):
    """Run Claude until it answers the user. Returns (reply text, new draft cards)."""
    new_drafts, texts = [], []
    tool_defs = tools(c, ctx)
    system = system_prompt(ctx, focus)
    for _ in range(MAX_TOOL_ROUNDS):
        resp = client().beta.messages.create(
            model=MODEL,
            max_tokens=16000,
            output_config={"effort": "medium"},
            # if a safety classifier declines, the API retries on a suitable model inside the same call
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",
            system=[{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}],
            tools=tool_defs,
            messages=st["messages"],
        )
        st["messages"].append({"role": "assistant", "content": resp.content})   # append-only history
        texts += [b.text for b in resp.content if b.type == "text" and b.text.strip()]
        if resp.stop_reason == "refusal":
            return "Sorry, I can't help with that request. I can help you add AIDASH records for your accounts.", new_drafts
        if resp.stop_reason == "pause_turn":
            continue
        uses = [b for b in resp.content if b.type == "tool_use"]
        if resp.stop_reason != "tool_use" or not uses:
            if resp.stop_reason == "max_tokens":
                texts.append("(The reply was cut short; please ask again more briefly.)")
            return "\n\n".join(texts) or "OK.", new_drafts
        results = []
        for u in uses:
            try:
                out, is_err = run_tool(c, st, u.name, dict(u.input or {}), new_drafts, ctx)
            except Exception as e:   # never let a tool failure break the conversation
                out, is_err = f"Tool failed: {e}", True
            results.append({"type": "tool_result", "tool_use_id": u.id, "content": out, "is_error": is_err})
        st["messages"].append({"role": "user", "content": results})
    return "\n\n".join(texts) or "Sorry, that took too many steps. Please try again.", new_drafts


# ---------------------------------------------------------------- routes
def _user_only():
    if g.is_admin:
        abort(403, "user_only")


def transcript(st):
    """(visible history, draft cards) of a conversation, for rendering it again."""
    history = []
    for m in st["messages"]:   # user text, assistant text, notes
        content = m["content"]
        if m["role"] == "user" and isinstance(content, str):
            history.append({"role": "note" if content.startswith("[") else "user", "text": content})
        elif m["role"] == "assistant":
            text = "\n\n".join(b.text for b in content if getattr(b, "type", "") == "text" and b.text.strip())
            if text:
                history.append({"role": "assistant", "text": text})
    return history, [draft_view(d) for d in st["drafts"].values()]


def widget_context(ctx="autonomy"):
    """Template values for the chat panel on a data screen (regular users only)."""
    if g.is_admin:
        return {}
    history, drafts = transcript(chat_state(ctx))
    return {"chat_configured": bool(api_key()), "chat_history": history, "chat_drafts": drafts}


def entity_widget_context(c, name, customer_id=None, record_id=None):
    """Panel values for a Key Deals / Touchpoints / Engineers / Assets screen, focused on the record or customer
    open in the form (only if it is one of the user's customers)."""
    out = widget_context(name)
    if not out:
        return out
    try:
        cid = int(customer_id or 0)
    except (TypeError, ValueError):
        cid = 0
    row = c.execute("SELECT name FROM customer WHERE id=?", (cid,)).fetchone() if cid else None
    ok = bool(row) and H["customer_in_scope"](c, cid)
    out.update(chat_focus_id=cid if ok else None, chat_focus=row["name"] if ok else None,
               chat_record_id=record_id if ok else None)
    return out


@bp.route("/chat")
def page():
    _user_only()
    history, drafts = transcript(chat_state())
    return render_template("chat.html", configured=bool(api_key()), history=history, drafts=drafts)


@bp.post("/chat/send")
def send():
    _user_only()
    if not api_key():
        return jsonify(error="The AI chat is not configured yet: an administrator must add the Anthropic API key."), 503
    text = ((request.get_json(silent=True) or {}).get("message") or "").strip()
    if not text:
        return jsonify(error="Type a message."), 400
    if len(text) > 4000:
        return jsonify(error="Message too long (max 4000 characters)."), 400
    import anthropic
    ctx = read_ctx()
    st = chat_state(ctx)
    c = H["conn"]()
    body = request.get_json(silent=True) or {}
    focus = None   # the account (and record being edited) open on the screen, if it is the user's
    try:
        fid = int(body.get("customer_id") or 0)
        rid = int(body.get("record_id") or 0)
    except (TypeError, ValueError):
        fid = rid = 0
    if rid and ctx in H["ENTITIES"]:
        rec = record_row(c, ctx, rid)
        fid = rec["customer_id"] if rec else fid
        rid = rid if rec else 0
    if fid and H["customer_in_scope"](c, fid):
        row = c.execute("""SELECT cu.id, cu.name, i.name isu, b.name bg FROM customer cu JOIN isu i ON i.id=cu.isu_id
            JOIN bg b ON b.id=i.bg_id WHERE cu.id=?""", (fid,)).fetchone()
        focus = dict(id=row["id"], name=row["name"], isu=row["isu"], bg=row["bg"], record_id=rid or None) if row else None
    st["messages"].append({"role": "user", "content": text})
    try:
        reply, drafts = ask_claude(c, st, ctx, focus)
    except anthropic.AuthenticationError:
        return jsonify(error="The Anthropic API key was rejected. Ask an administrator to check it."), 502
    except anthropic.RateLimitError:
        return jsonify(error="The AI service is busy right now. Please try again in a minute."), 503
    except anthropic.APIConnectionError:
        return jsonify(error="Cannot reach the AI service from this server. Please try again."), 502
    except anthropic.APIStatusError as e:
        return jsonify(error=f"AI service error ({e.status_code}). Please try again."), 502
    finally:
        c.close()
    return jsonify(reply=reply, drafts=drafts)


@bp.post("/chat/draft/<did>/<action>")
def draft_action(did, action):
    _user_only()
    st = chat_state(read_ctx())
    d = st["drafts"].get(did)
    if not d or action not in ("confirm", "cancel"):
        abort(404)
    if d["status"] != "pending":
        return jsonify(error=f"This draft was already {d['status']}."), 409
    if action == "cancel":
        d["status"] = "cancelled"
        st["messages"].append({"role": "user", "content": f"[The user cancelled draft {did}; nothing was saved.]"})
        return jsonify(status="cancelled", note="Cancelled. Nothing was saved.")
    c = H["conn"]()
    try:
        # re-check everything at save time: scope or data may have changed since the draft was made
        errors = validate_draft(c, d)
        if errors:
            return jsonify(error="Not saved: " + "; ".join(errors) + "."), 400
        try:
            what = save_draft(c, d)
        except (H["IntegrityError"], ValueError) as e:
            return jsonify(error=f"Not saved: {e}"), 400
    finally:
        c.close()
    d["status"] = "saved"
    note = f"Saved: {what} for {d['customer']}."
    st["messages"].append({"role": "user", "content": f"[The user confirmed draft {did}. {note}]"})
    return jsonify(status="saved", note=note, customer_id=d["customer_id"])


@bp.post("/chat/reset")
def reset():
    _user_only()
    ctx = read_ctx()
    with _lock:
        _chats.pop((session["user"], ctx), None)
    return jsonify(ok=True)
