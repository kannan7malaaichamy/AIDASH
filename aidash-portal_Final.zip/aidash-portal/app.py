"""AI Synapse - TCS AI Journey Insights Portal: data collection and running BG leaderboard (Flask + SQLite)."""
import os
import re
import sqlite3
from collections import defaultdict
from datetime import date
from functools import wraps

from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash

import db
import insights

app = Flask(__name__)
app.secret_key = os.environ.get("AIDASH_SECRET_KEY", "aidash-dev-key-change-me")

YN = ["Y", "N"]

# Generic single-page entities: (field, label, kind, options)
# kind: text | textarea | select | month | date | number ; options: list or "lookup:<category>"
ENTITIES = {
    "deals": {
        "title": "Key Deals", "table": "deal", "order": "reporting_month DESC, id DESC",
        "month_field": "reporting_month",
        "fields": [
            ("opportunity_id", "Opportunity ID", "text", None),
            ("opportunity_type", "Opportunity type", "select", db.DEAL_TYPES),
            ("deal_name", "Opportunity / deal name", "text", None),
            ("status", "Status", "select", db.DEAL_STATUSES),
            ("description", "Description", "textarea", None),
            ("client_context", "Client context", "textarea", None),
            ("past_failure_reasons", "Why past efforts failed", "textarea", None),
            ("deal_size", "Deal size", "select", ["Small", "Medium", "Large", "Mega"]),
            ("deal_value", "Deal value (USD M)", "number", None),
            ("pursuit_lead", "Pursuit lead", "text", None),
            ("pitch_focus", "Focus of pitch & key value propositions", "textarea", None),
            ("resonated", "What resonated", "textarea", None),
            ("not_resonated", "What did not resonate / reason for failure", "textarea", None),
            ("entry_date", "Date of entry", "date", None),
            ("reporting_month", "Reporting month", "month", None),
            ("win_team", "Win team", "text", None),
            ("competitor", "Competitor", "text", None),
        ],
        "list_cols": ["opportunity_id", "opportunity_type", "deal_name", "status", "deal_value",
                      "pursuit_lead", "reporting_month", "competitor"],
    },
    "touchpoints": {
        "title": "Customer Touchpoints", "table": "touchpoint", "order": "reporting_month DESC, id DESC",
        "month_field": "reporting_month",
        "fields": [
            ("engagement_type", "Type of engagement", "select", "lookup:engagement_type"),
            ("reporting_month", "Reporting month", "month", None),
            ("customer_participants", "Customer participants", "textarea", None),
            ("tcs_participants", "TCS participants", "textarea", None),
            ("focus_areas", "Key focus areas", "textarea", None),
        ],
        "list_cols": ["engagement_type", "customer_participants", "tcs_participants", "focus_areas",
                      "reporting_month"],
    },
    "engineers": {
        "title": "Distinguished Engineers", "table": "engineer", "order": "month_added DESC, id DESC",
        "month_field": "month_added",
        "fields": [
            ("associate_name", "Associate name", "text", None),
            ("employee_number", "Employee number", "text", None),
            ("location", "Location", "text", None),
            ("role_type", "Role type", "select", "lookup:role_type"),
            ("month_added", "Month added", "month", None),
        ],
        "list_cols": ["associate_name", "employee_number", "location", "role_type", "month_added"],
    },
    "assets": {
        "title": "Asset Contribution", "table": "asset", "order": "contribution_month DESC, id DESC",
        "month_field": "contribution_month",
        "fields": [
            ("asset_name", "Asset name", "text", None),
            ("status", "Status", "select", "lookup:asset_status"),
            ("description", "Description", "textarea", None),
            ("contribution_month", "Month of contribution", "month", None),
            ("asset_count", "Number of assets contributed", "number", None),
            ("contributor", "Contributor name", "text", None),
            ("core_platform", "Contributed to TCS core platform", "select", YN),
        ],
        "list_cols": ["asset_name", "status", "contribution_month", "asset_count", "contributor",
                      "core_platform"],
    },
}
REQUIRED = {"associate_name", "employee_number", "deal_name", "asset_name", "engagement_type"}

# ---- Data completeness rules ("Data Incomplete Accounts" filter)
# Fields a record must have filled in to count as complete (beyond the hard REQUIRED ones).
COMPLETE_FIELDS = {
    "deals": ["opportunity_id", "opportunity_type", "deal_name", "status", "deal_value", "pursuit_lead",
              "entry_date", "reporting_month", "competitor"],
    "touchpoints": ["engagement_type", "customer_participants", "tcs_participants", "focus_areas", "reporting_month"],
    "engineers": ["associate_name", "employee_number", "location", "role_type", "month_added"],
    "assets": ["asset_name", "status", "contribution_month", "asset_count", "contributor", "core_platform"],
}
AUTONOMY_FIELDS = [("workshop_completed", "Workshop completed"), ("mega_ai_journey", "Mega AI Journey"),
                   ("headcount_band", "Headcount band"), ("target_level", "Target level"),
                   ("target_quarter", "Target quarter")]
SECTIONS = [("autonomy", "AI Service Autonomy"), ("deals", "Key Deals"), ("touchpoints", "Customer Touchpoints"),
            ("engineers", "Distinguished Engineers"), ("assets", "Asset Contribution")]


def blank(v):
    return v is None or (isinstance(v, str) and not v.strip())


def record_missing(name, row):
    """Labels of the fields this record is missing."""
    labels = {f: l for f, l, *_ in ENTITIES[name]["fields"]}
    out = [labels[f] for f in COMPLETE_FIELDS[name] if blank(row[f])]
    if name == "deals":
        if row["status"] == "Won" and blank(row["win_team"]):
            out.append(labels["win_team"])
        if row["status"] == "Lost" and blank(row["not_resonated"]):
            out.append(labels["not_resonated"])
    return out

LOOKUP_LABELS = {"engagement_type": "Customer touchpoint: type of engagement",
                 "role_type": "Distinguished engineer: role type",
                 "asset_status": "Asset contribution: status"}


# ---------------------------------------------------------------- helpers
def conn():
    return db.connect()


def customer_tree(c, bg="", isu="", must_include=None):
    """[(bg, isu, [customer rows])] for grouped <select>s, narrowed to the BG/ISU filter.
    Falls back to the full list when must_include (e.g. the record being edited) is outside the filter."""
    where, params = filter_where(bg, isu)
    if must_include and where:
        hit = c.execute("""SELECT 1 FROM customer cu JOIN isu i ON i.id=cu.isu_id JOIN bg b ON b.id=i.bg_id"""
                        + where + " AND cu.id=?", (*params, must_include)).fetchone()
        if not hit:
            where, params = "", ()
    rows = c.execute("""SELECT cu.id, cu.name, i.name isu, b.name bg FROM customer cu
        JOIN isu i ON i.id = cu.isu_id JOIN bg b ON b.id = i.bg_id""" + where
                     + " ORDER BY b.id, i.id, cu.name", params).fetchall()
    groups, out = {}, []
    for r in rows:
        key = (r["bg"], r["isu"])
        if key not in groups:
            groups[key] = []
            out.append((r["bg"], r["isu"], groups[key]))
        groups[key].append(r)
    return out


def customer_in_scope(c, cid):
    """True if the signed-in user may see/change this customer. Regular users: only customers where they are the
    AccountAI-SPOC; BG-scoped: own BG only; ISU-scoped: own ISU only."""
    if g.get("scope_cids") is not None and cid not in g.scope_cids:
        return False
    if not g.get("scope_bg"):
        return True
    r = c.execute("""SELECT b.name bg, i.name isu FROM customer cu JOIN isu i ON i.id=cu.isu_id
        JOIN bg b ON b.id=i.bg_id WHERE cu.id=?""", (cid,)).fetchone()
    if not r or r["bg"] != g.scope_bg:
        return False
    return not g.get("scope_isu") or r["isu"] == g.scope_isu


def require_scope(c, cid):
    if not customer_in_scope(c, cid):
        c.close()
        abort(403, "out_of_scope")


def bg_names(c):
    if g.get("scope_bg"):
        return [g.scope_bg]
    names = [r["name"] for r in c.execute("SELECT name FROM bg ORDER BY id")]
    if g.get("scope_cids") is not None:   # only BGs that hold the user's customers
        mine = {r["bg"] for r in scope_isu_rows(c)}
        names = [n for n in names if n in mine]
    return names


def scope_isu_rows(c):
    """(isu, bg) of the ISUs holding the signed-in user's own customers."""
    cids = sorted(g.get("scope_cids") or ())
    if not cids:
        return []
    return c.execute(f"""SELECT DISTINCT i.name isu, b.name bg FROM customer cu JOIN isu i ON i.id=cu.isu_id
        JOIN bg b ON b.id=i.bg_id WHERE cu.id IN ({', '.join('?' * len(cids))})""", cids).fetchall()


def read_filters(c):
    """(bg, isu, isu_rows) from the request; an ISU always pins its own BG, unknown values are dropped."""
    bg = request.values.get("bg") or ""
    isu = request.values.get("isu") or ""
    isu_rows = c.execute("""SELECT i.name isu, b.name bg FROM isu i JOIN bg b ON b.id=i.bg_id
        ORDER BY b.id, i.id""").fetchall()
    isu_bg = {r["isu"]: r["bg"] for r in isu_rows}
    if bg not in isu_bg.values():
        bg = ""
    if isu not in isu_bg:
        isu = ""
    elif isu_bg[isu] != bg:
        bg = isu_bg[isu]
    scope = g.get("scope_bg")
    if scope:   # BG-scoped users are pinned to their BG whatever the request says
        bg = scope
        if isu and isu_bg.get(isu) != scope:
            isu = ""
        isu_rows = [r for r in isu_rows if r["bg"] == scope]
    if g.get("scope_isu"):   # ISU-scoped users are pinned to their ISU (and its BG)
        isu = g.scope_isu
        isu_rows = [r for r in isu_rows if r["isu"] == isu]
    if g.get("scope_cids") is not None:   # regular users: only BGs/ISUs that hold their own customers
        mine = {r["isu"] for r in scope_isu_rows(c)}
        isu_rows = [r for r in isu_rows if r["isu"] in mine]
        if isu not in mine:
            isu = ""
        my_bgs = {r["bg"] for r in isu_rows}
        if bg and bg not in my_bgs:
            bg = ""
        if len(my_bgs) == 1:   # all their customers sit in one BG: show it rather than "All BGs"
            bg = next(iter(my_bgs))
    return bg, isu, isu_rows


def read_quarter():
    """(quarter code or '', months to show). No quarter selected -> all FY months to date."""
    q = request.values.get("q") or ""
    for code, _label, ms in db.fy_quarters():
        if code == q:
            return q, ms
    return "", db.fy_months()


def filter_where(bg, isu, month_col=None, months=None):
    """WHERE clause on aliases i (isu) / b (bg), optionally restricting month_col to months."""
    conds, params = [], []
    cids = g.get("scope_cids")
    if cids is not None:   # regular users: only the customers where they are the AccountAI-SPOC
        if cids:
            conds.append(f"cu.id IN ({', '.join('?' * len(cids))})")
            params += sorted(cids)
        else:
            conds.append("1=0")
    if isu:
        conds.append("i.name=?")
        params.append(isu)
    elif bg:
        conds.append("b.name=?")
        params.append(bg)
    if month_col and months:
        conds.append(f"{month_col} IN ({', '.join('?' * len(months))})")
        params += months
    return (" WHERE " + " AND ".join(conds) if conds else ""), tuple(params)


def options_for(c, opts):
    if isinstance(opts, str) and opts.startswith("lookup:"):
        cat = opts.split(":", 1)[1]
        return [r["value"] for r in c.execute("SELECT value FROM lookup WHERE category=? ORDER BY id", (cat,))]
    return opts or []


def maturity_by_month(c, months):
    """{customer_id: {month: level}} - level of latest assessment on/before month end; derived, never typed."""
    hist = defaultdict(list)
    for r in c.execute("SELECT customer_id, level, assessment_date FROM assessment ORDER BY assessment_date, id"):
        hist[r["customer_id"]].append((r["assessment_date"], r["level"]))
    out = {}
    for cid, items in hist.items():
        row = {}
        for m in months:
            end = db.month_end(m)
            lvl = None
            for d, l in items:
                if d <= end:
                    lvl = l
                else:
                    break
            row[m] = lvl
        out[cid] = row
    return out


# ---------------------------------------------------------------- authentication
PUBLIC_ENDPOINTS = {"login", "static"}


@app.before_request
def require_login():
    g.is_admin = False
    g.scope_bg = None
    g.scope_isu = None
    g.scope_cids = None   # None = no customer limit (admins); a set = the only customers a user may access
    if request.endpoint in PUBLIC_ENDPOINTS:
        return None
    if "user" in session:
        c = conn()
        u = c.execute("SELECT is_admin, scope_bg, scope_isu FROM app_user WHERE username=?",
                      (session["user"],)).fetchone()
        problem = None
        if u:   # role and BG/ISU scope are read from the DB on every request, so changes apply immediately
            g.is_admin = bool(u["is_admin"])
            g.scope_bg = u["scope_bg"] or None
            if u["scope_isu"]:   # an ISU limit implies its BG
                r = c.execute("SELECT b.name FROM isu i JOIN bg b ON b.id=i.bg_id WHERE i.name=?",
                              (u["scope_isu"],)).fetchone()
                g.scope_isu, g.scope_bg = u["scope_isu"], (r["name"] if r else None)
                if not r:
                    problem = f"Your ISU '{u['scope_isu']}' no longer exists. Ask an administrator to update your account."
            elif g.scope_bg and not c.execute("SELECT 1 FROM bg WHERE name=?", (g.scope_bg,)).fetchone():
                problem = f"Your BG '{g.scope_bg}' no longer exists. Ask an administrator to update your account."
            if not g.is_admin:   # a user's customers are those whose AccountAI-SPOC emp no is their user ID
                g.scope_cids = {r[0] for r in c.execute(
                    "SELECT id FROM customer WHERE TRIM(spoc_emp_no)=? COLLATE NOCASE", (session["user"],))}
        c.close()
        if u and not problem:
            return None
        session.clear()   # account removed, or its BG/ISU is gone: sign out rather than show everything
        if problem:
            flash(problem, "error")
    return redirect(url_for("login", next=request.full_path if request.query_string else request.path))


def admin_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if not g.is_admin:
            abort(403)
        return view(*args, **kwargs)
    return wrapper


def admin_home(view):
    """The leaderboard is for admins only; regular users are sent to their own accounts instead.
    (A decorator because dashboard() uses a local variable named g.)"""
    @wraps(view)
    def wrapper(*args, **kwargs):
        if not g.is_admin:
            return redirect(url_for("autonomy"))
        return view(*args, **kwargs)
    return wrapper


def user_only(view):
    """New data entry on the data screens is reserved for regular (non-admin) users."""
    @wraps(view)
    def wrapper(*args, **kwargs):
        if g.is_admin:
            abort(403, "user_only")
        return view(*args, **kwargs)
    return wrapper


@app.errorhandler(403)
def forbidden(e):
    desc = getattr(e, "description", "")
    return render_template("forbidden.html", user_only=desc == "user_only", out_of_scope=desc == "out_of_scope"), 403


def safe_next(target):
    """Only allow same-site relative redirects after login."""
    if target and target.startswith("/") and not target.startswith("//") and "\\" not in target:
        return target
    return url_for("dashboard")   # the leaderboard sends regular users on to AI Service Autonomy


@app.route("/login", methods=["GET", "POST"])
def login():
    if "user" in session:
        return redirect(url_for("dashboard"))
    error = None
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        c = conn()
        u = c.execute("SELECT * FROM app_user WHERE username=?", (username,)).fetchone()
        c.close()
        if u and check_password_hash(u["password_hash"], request.form.get("password") or ""):
            session.clear()
            session["user"] = u["username"]
            session["full_name"] = u["full_name"] or u["username"]
            return redirect(safe_next(request.form.get("next")))
        error = "Invalid username or password."
    return render_template("login.html", error=error, next=request.values.get("next", ""))


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


def read_inc():
    return "1" if request.values.get("inc") == "1" else ""


def period_label(q, months):
    return q or f"FY27 to date ({db.month_label(months[0])} to {db.month_label(months[-1])})"


def current_month():
    return db.fy_months()[-1]


def inc_label():
    return f"{db.month_label(current_month())} (current month)"


def completeness(c):
    """{customer_id: {section: [reasons]}} for every account with a data gap in the CURRENT month.
    Deals, touchpoints and assets need a complete record dated in the current month; engineers and
    autonomy are cumulative up to the current month's end."""
    last = current_month()
    mset = {last}
    end = db.month_end(last)
    gaps = defaultdict(lambda: defaultdict(list))
    cids = [r["id"] for r in c.execute("SELECT id FROM customer")]
    period = db.month_label(last)

    # AI service autonomy
    prof = {r["customer_id"]: r for r in c.execute("SELECT * FROM autonomy")}
    assessed = {r[0] for r in c.execute("SELECT DISTINCT customer_id FROM assessment WHERE assessment_date<=?", (end,))}
    plans = defaultdict(list)
    for r in c.execute("SELECT customer_id, owner, due_date FROM plan_item"):
        plans[r["customer_id"]].append(r)
    for cid in cids:
        p = prof.get(cid)
        miss = [lbl for f, lbl in AUTONOMY_FIELDS if not p or blank(p[f])]
        if miss:
            gaps[cid]["autonomy"].append("Profile missing: " + ", ".join(miss))
        if cid not in assessed:
            gaps[cid]["autonomy"].append("No assessment yet")
        if not plans[cid]:
            gaps[cid]["autonomy"].append("No 30-60-90 plan items")
        else:
            bad = sum(1 for r in plans[cid] if blank(r["owner"]) or blank(r["due_date"]))
            if bad:
                gaps[cid]["autonomy"].append(f"{bad} plan item(s) missing owner/due date")

    # record-based sections
    for name, cfg in ENTITIES.items():
        mf = cfg["month_field"]
        cumulative = name == "engineers"
        per_cid = defaultdict(list)
        for r in c.execute(f"SELECT * FROM {cfg['table']}"):
            m = r[mf]
            if m and ((m <= last) if cumulative else (m in mset)):
                per_cid[r["customer_id"]].append(r)
        for cid in cids:
            recs = per_cid.get(cid)
            if not recs:
                gaps[cid][name].append(f"No engineers added by {period}" if cumulative else f"No records for {period}")
                continue
            fields = defaultdict(int)
            for r in recs:
                for lbl in record_missing(name, r):
                    fields[lbl] += 1
            if fields:
                n = sum(1 for r in recs if record_missing(name, r))
                gaps[cid][name].append(f"{n} record(s) missing: " + ", ".join(fields))
    return gaps


def scoped_customers(c, bg, isu):
    where, params = filter_where(bg, isu)
    return c.execute("""SELECT cu.id, cu.name, i.name isu, b.name bg FROM customer cu
        JOIN isu i ON i.id=cu.isu_id JOIN bg b ON b.id=i.bg_id""" + where
                     + " ORDER BY b.id, i.id, cu.name", params).fetchall()


@app.context_processor
def inject():
    return {"month_label": db.month_label, "nav_entities": [(k, v["title"]) for k, v in ENTITIES.items()],
            "is_admin": g.get("is_admin", False), "scope_bg": g.get("scope_bg"), "scope_isu": g.get("scope_isu"),
            "no_customers": g.get("scope_cids") is not None and not g.scope_cids,
            "quarters": db.fy_quarters(), "q_filter": read_quarter()[0], "inc_filter": read_inc()}


# ---------------------------------------------------------------- dashboard
@app.route("/")
@admin_home
def dashboard():
    c = conn()
    _q, months = read_quarter()
    bg_filter, isu_filter, isu_rows = read_filters(c)
    # group key per customer: BG -> ISU (one BG selected) -> customer (one ISU selected)
    if isu_filter:
        rows = c.execute("""SELECT cu.id cid, cu.name grp FROM customer cu JOIN isu i ON i.id=cu.isu_id
            WHERE i.name=? ORDER BY cu.name""", (isu_filter,)).fetchall()
        level = "Customer"
    elif bg_filter:
        rows = c.execute("""SELECT cu.id cid, i.name grp FROM customer cu JOIN isu i ON i.id=cu.isu_id
            JOIN bg b ON b.id=i.bg_id WHERE b.name=? ORDER BY i.id""", (bg_filter,)).fetchall()
        level = "ISU"
    else:
        rows = c.execute("""SELECT cu.id cid, b.name grp FROM customer cu JOIN isu i ON i.id=cu.isu_id
            JOIN bg b ON b.id=i.bg_id ORDER BY b.id""").fetchall()
        level = "BG"
    grp_of = {r["cid"]: r["grp"] for r in rows}
    groups = list(dict.fromkeys(r["grp"] for r in rows))

    def blank():
        return {g: {m: 0 for m in months} for g in groups}

    l2, l3, won, tp, de, assets = blank(), blank(), blank(), blank(), blank(), blank()

    for cid, per_month in maturity_by_month(c, months).items():
        g = grp_of.get(cid)
        if g is None:
            continue
        for m, lvl in per_month.items():
            if lvl == "L2":
                l2[g][m] += 1
            elif lvl == "L3":
                l3[g][m] += 1

    def add_counts(target, sql, cumulative=False):
        for r in c.execute(sql):
            g = grp_of.get(r["customer_id"])
            if g is None or not r["m"]:
                continue
            for m in months:
                if (r["m"] <= m) if cumulative else (r["m"] == m):
                    target[g][m] += r["n"]

    add_counts(won, "SELECT customer_id, reporting_month m, 1 n FROM deal WHERE status='Won'")
    add_counts(tp, "SELECT customer_id, reporting_month m, 1 n FROM touchpoint")
    add_counts(de, "SELECT customer_id, month_added m, 1 n FROM engineer", cumulative=True)
    add_counts(assets, "SELECT customer_id, contribution_month m, COALESCE(asset_count,0) n FROM asset")

    last = months[-1]

    def board(key, title, data, total_mode, note):
        # total_mode: 'sum' (FYTD total) or 'last' (point-in-time snapshot at latest month)
        rows_ = []
        for g in groups:
            vals = [data[g][m] for m in months]
            total = sum(vals) if total_mode == "sum" else vals[-1]
            rows_.append({"name": g, "vals": vals, "total": total})
        rows_.sort(key=lambda r: (-r["total"], -r["vals"][-1], r["name"]))
        rank, prev = 0, None
        for i, r in enumerate(rows_, 1):
            if r["total"] != prev:
                rank, prev = i, r["total"]
            r["rank"] = rank
        col_tot = [sum(r["vals"][i] for r in rows_) for i in range(len(months))]
        grand = sum(col_tot) if total_mode == "sum" else col_tot[-1]
        return {"key": key, "title": title, "rows": rows_, "col_tot": col_tot, "grand": grand,
                # snapshot boards rank by the highlighted last month, so they need no separate total column
        "total_label": ("QTD" if _q else "FYTD") if total_mode == "sum" else None,
        "note": note,
                "kpi": col_tot[-1]}

    boards = [
        board("l2", "AI Service Autonomy: accounts in L2", l2, "last", "Point-in-time; derived from latest assessment on/before month end"),
        board("l3", "AI Service Autonomy: accounts in L3", l3, "last", "Point-in-time; derived from latest assessment on/before month end"),
        board("won", "Key Deals: deals won", won, "sum", "By reporting month"),
        board("tp", "Customer Touchpoints", tp, "sum", "By reporting month"),
        board("de", "Distinguished Engineers", de, "last", "Running headcount (cumulative by month added)"),
        board("assets", "Assets Contributed", assets, "sum", "Sum of number of assets, by month of contribution"),
    ]
    # Key AI insights from three sections, same logic and scope as the section pages
    key_insights = []
    for name in ("deals", "engineers", "assets"):
        recs = scoped_records(c, name, bg_filter, isu_filter, _q, months)
        key_insights.append({"name": name, "title": ENTITIES[name]["title"],
                             "items": section_insights(c, name, recs, bg_filter, isu_filter, months)})

    out = render_template("dashboard.html", boards=boards, months=months, last=last, level=level,
                          key_insights=key_insights, bgs=bg_names(c), bg_filter=bg_filter,
                          isu_filter=isu_filter, isu_rows=isu_rows)
    c.close()
    return out


# ---------------------------------------------------------------- AI service autonomy
@app.route("/autonomy")
def autonomy():
    c = conn()
    all_months = db.fy_months()
    _q, months = read_quarter()
    bg_filter, isu_filter, isu_rows = read_filters(c)
    cid = request.args.get("customer", type=int)
    if cid:
        require_scope(c, cid)
    sql = """SELECT cu.id, cu.name, i.name isu, b.name bg, a.* FROM customer cu
        JOIN isu i ON i.id=cu.isu_id JOIN bg b ON b.id=i.bg_id
        LEFT JOIN autonomy a ON a.customer_id=cu.id"""
    where, params = filter_where(bg_filter, isu_filter)
    rows = c.execute(sql + where + " ORDER BY b.id, i.id, cu.name", params).fetchall()
    mat = maturity_by_month(c, all_months)

    # Top 3 AI insights for the scope (computed before the incomplete-accounts filter narrows the rows)
    last_assessed = {r[0]: r[1] for r in c.execute(
        "SELECT customer_id, MAX(assessment_date) FROM assessment WHERE assessment_date <= ? GROUP BY customer_id",
        (db.month_end(months[-1]),))}
    plans_all = c.execute("SELECT customer_id, status, due_date FROM plan_item").fetchall()
    cur_q = db.fy_quarters()[-1][0]
    ai_insights = insights.autonomy(rows, mat, months, last_assessed, plans_all, date.today().isoformat(), cur_q, k=3)
    snapshot = insights.maturity_snapshot(rows, mat, months[-1])

    gaps = {}
    if read_inc():
        gaps = {k: v["autonomy"] for k, v in completeness(c).items() if v.get("autonomy")}
        rows = [r for r in rows if r["id"] in gaps]

    sel = profile = None
    plans = assessments = []
    if cid:
        sel = c.execute("""SELECT cu.id, cu.name, i.name isu, b.name bg FROM customer cu
            JOIN isu i ON i.id=cu.isu_id JOIN bg b ON b.id=i.bg_id WHERE cu.id=?""", (cid,)).fetchone()
        if not sel:
            abort(404)
        profile = c.execute("SELECT * FROM autonomy WHERE customer_id=?", (cid,)).fetchone()
        plans = c.execute("SELECT * FROM plan_item WHERE customer_id=? ORDER BY due_date", (cid,)).fetchall()
        assessments = c.execute("SELECT * FROM assessment WHERE customer_id=? ORDER BY assessment_date",
                                (cid,)).fetchall()
    out = render_template(
        "autonomy.html", rows=rows, months=months, current_month=all_months[-1], mat=mat, gaps=gaps,
        ai_insights=ai_insights, snapshot=snapshot, insight_scope=period_label(_q, months),
        period=inc_label(),
        bgs=bg_names(c), bg_filter=bg_filter,
        isu_filter=isu_filter, isu_rows=isu_rows,
        tree=customer_tree(c, bg_filter, isu_filter, cid), sel=sel, profile=profile, plans=plans, assessments=assessments,
        levels=db.LEVELS, bands=db.HEADCOUNT_BANDS, plan_statuses=db.PLAN_STATUSES, yn=YN,
        **chat_ai.widget_context())   # AI chat panel (regular users)
    c.close()
    return out


def back_to_customer(cid):
    return redirect(url_for("autonomy", customer=cid, bg=request.form.get("bg", ""),
                            isu=request.form.get("isu", ""), q=request.form.get("q", ""),
                            inc=request.form.get("inc", "")) + "#editor")


@app.post("/autonomy/new")
@user_only
def autonomy_new():
    """One-form capture: profile (create, or fill blank fields), optional assessment, optional plan item."""
    f = request.form
    cid = f.get("customer_id", type=int)
    c = conn()
    if not cid or not c.execute("SELECT 1 FROM customer WHERE id=?", (cid,)).fetchone():
        c.close()
        flash("Select a customer.", "error")
        return redirect(url_for("autonomy", bg=f.get("bg", ""), isu=f.get("isu", ""), q=f.get("q", ""),
                                inc=f.get("inc", "")) + "#new")
    require_scope(c, cid)
    prof_fields =["workshop_completed", "mega_ai_journey", "headcount_band", "target_level", "target_quarter"]
    prof = {k: (f.get(k) or "").strip() or None for k in prof_fields}
    a_type, a_level, a_date = f.get("a_type"), f.get("a_level"), f.get("a_date")
    a_any = any([a_level, a_date, f.get("a_score")])
    item = (f.get("p_item") or "").strip()

    errors = []
    if a_any and not (a_type in ("Baseline", "Reassessment") and a_level in db.LEVELS and a_date):
        errors.append("an assessment needs type, level and date")
    if not item and (f.get("p_owner") or f.get("p_due")):
        errors.append("a plan item needs its description")
    if not errors and not any(prof.values()) and not a_any and not item:
        errors.append("enter at least one profile field, an assessment or a plan item")
    if errors:
        c.close()
        flash("Not saved: " + "; ".join(errors) + ".", "error")
        return redirect(url_for("autonomy", bg=f.get("bg", ""), isu=f.get("isu", ""), q=f.get("q", ""),
                                inc=f.get("inc", "")) + "#new")

    done = []
    existing = c.execute("SELECT * FROM autonomy WHERE customer_id=?", (cid,)).fetchone()
    if any(prof.values()):
        if existing:   # fill in only the fields provided; never blank out existing values
            sets = {k: v for k, v in prof.items() if v}
            c.execute("UPDATE autonomy SET " + ", ".join(f"{k}=?" for k in sets) + " WHERE customer_id=?",
                      (*sets.values(), cid))
            done.append("profile updated")
        else:
            c.execute("INSERT INTO autonomy(customer_id, " + ", ".join(prof_fields) + ") VALUES (?,?,?,?,?,?)",
                      (cid, *prof.values()))
            done.append("profile created")
    if a_any:
        c.execute("INSERT INTO assessment(customer_id, type, score, level, assessment_date) VALUES (?,?,?,?,?)",
                  (cid, a_type, f.get("a_score") or None, a_level, a_date))
        done.append("assessment added")
    if item:
        c.execute("INSERT INTO plan_item(customer_id, item, owner, due_date, status) VALUES (?,?,?,?,?)",
                  (cid, item, (f.get("p_owner") or "").strip(), f.get("p_due") or None, f.get("p_status")))
        done.append("plan item added")
    c.commit()
    c.close()
    flash("Saved: " + ", ".join(done) + ".")
    return redirect(url_for("autonomy", customer=cid, bg=f.get("bg", ""), isu=f.get("isu", ""), q=f.get("q", ""),
                            inc=f.get("inc", "")) + "#editor")


@app.post("/autonomy/<int:cid>/profile")
def autonomy_profile(cid):
    f = request.form
    c = conn()
    require_scope(c, cid)
    # creating a profile is new data (users only); admins may only modify an existing one
    if g.is_admin and not c.execute("SELECT 1 FROM autonomy WHERE customer_id=?", (cid,)).fetchone():
        c.close()
        abort(403, "user_only")
    c.execute("""INSERT INTO autonomy(customer_id, workshop_completed, mega_ai_journey, headcount_band,
        target_level, target_quarter) VALUES (?,?,?,?,?,?)
        ON CONFLICT(customer_id) DO UPDATE SET workshop_completed=excluded.workshop_completed,
        mega_ai_journey=excluded.mega_ai_journey, headcount_band=excluded.headcount_band,
        target_level=excluded.target_level, target_quarter=excluded.target_quarter""",
              (cid, f.get("workshop_completed"), f.get("mega_ai_journey"), f.get("headcount_band"),
               f.get("target_level"), f.get("target_quarter", "").strip()))
    c.commit()
    c.close()
    flash("Profile saved.")
    return back_to_customer(cid)


@app.post("/autonomy/<int:cid>/plan")
@user_only
def autonomy_plan_add(cid):
    f = request.form
    c = conn()
    require_scope(c, cid)
    if not f.get("item", "").strip():
        c.close()
        flash("Plan item text is required.", "error")
        return back_to_customer(cid)
    c.execute("INSERT INTO plan_item(customer_id, item, owner, due_date, status) VALUES (?,?,?,?,?)",
              (cid, f["item"].strip(), f.get("owner", "").strip(), f.get("due_date"), f.get("status")))
    c.commit()
    c.close()
    flash("Plan item added.")
    return back_to_customer(cid)


@app.post("/autonomy/plan/<int:pid>/update")
def autonomy_plan_update(pid):
    c = conn()
    r = c.execute("SELECT customer_id FROM plan_item WHERE id=?", (pid,)).fetchone()
    if not r:
        abort(404)
    require_scope(c, r["customer_id"])
    c.execute("UPDATE plan_item SET status=? WHERE id=?", (request.form.get("status"), pid))
    c.commit()
    c.close()
    return back_to_customer(r["customer_id"])


@app.post("/autonomy/assessment/<int:cid>")
@user_only
def autonomy_assessment_add(cid):
    f = request.form
    c = conn()
    require_scope(c, cid)
    if not f.get("assessment_date") or f.get("level") not in db.LEVELS \
            or f.get("type") not in ("Baseline", "Reassessment"):
        c.close()
        flash("Assessment type, date and level are required.", "error")
        return back_to_customer(cid)
    c.execute("INSERT INTO assessment(customer_id, type, score, level, assessment_date) VALUES (?,?,?,?,?)",
              (cid, f.get("type"), f.get("score") or None, f["level"], f["assessment_date"]))
    c.commit()
    c.close()
    flash("Assessment added; monthly maturity recalculated.")
    return back_to_customer(cid)


@app.post("/autonomy/<kind>/<int:rid>/delete")
def autonomy_delete(kind, rid):
    table = {"plan": "plan_item", "assessment": "assessment"}.get(kind) or abort(404)
    c = conn()
    r = c.execute(f"SELECT customer_id FROM {table} WHERE id=?", (rid,)).fetchone()
    if not r:
        abort(404)
    require_scope(c, r["customer_id"])
    c.execute(f"DELETE FROM {table} WHERE id=?", (rid,))
    c.commit()
    c.close()
    flash("Deleted.")
    return back_to_customer(r["customer_id"])


# ---------------------------------------------------------------- generic entity pages
def scoped_records(c, name, bg, isu, q, q_months):
    """Records of a section within the BG/ISU filter and (if a quarter is chosen) that quarter."""
    cfg = ENTITIES[name]
    sql = f"""SELECT t.*, cu.name customer, i.name isu, b.name bg FROM {cfg['table']} t
        JOIN customer cu ON cu.id=t.customer_id JOIN isu i ON i.id=cu.isu_id JOIN bg b ON b.id=i.bg_id"""
    where, params = filter_where(bg, isu, "t." + cfg["month_field"], q_months if q else None)
    return c.execute(sql + where + f" ORDER BY t.{cfg['order'].replace(', ', ', t.')}", params).fetchall()


def section_insights(c, name, records, bg, isu, q_months, k=2):
    level = "Customer" if isu else "ISU" if bg else "BG"
    return insights.top_insights(name, records, level, q_months, len(scoped_customers(c, bg, isu)), k=k)


@app.route("/e/<name>", methods=["GET", "POST"])
def entity(name):
    cfg = ENTITIES.get(name) or abort(404)
    c = conn()
    bg_filter, isu_filter, isu_rows = read_filters(c)
    q_filter, q_months = read_quarter()

    if request.method == "POST" and g.is_admin and not request.form.get("id", type=int):
        c.close()
        abort(403, "user_only")   # adding new records is for regular users; admins may edit existing ones

    if request.method == "POST":
        f = request.form
        cid = f.get("customer_id", type=int)
        if cid:
            require_scope(c, cid)
        rid_ = f.get("id", type=int)
        if rid_:   # editing: the existing record must also be in scope
            old = c.execute(f"SELECT customer_id FROM {cfg['table']} WHERE id=?", (rid_,)).fetchone() or abort(404)
            require_scope(c, old["customer_id"])
        vals = {fld: (f.get(fld) or "").strip() or None for fld, *_ in cfg["fields"]}
        missing = [lbl for fld, lbl, *_ in cfg["fields"] if fld in REQUIRED and not vals[fld]]
        if not cid or missing:
            flash("Required: " + ", ".join((["Customer"] if not cid else []) + missing), "error")
        else:
            cols = ["customer_id"] + list(vals)
            try:
                rid = f.get("id", type=int)
                if rid:
                    c.execute(f"UPDATE {cfg['table']} SET " + ", ".join(f"{k}=?" for k in cols) + " WHERE id=?",
                              [cid, *vals.values(), rid])
                else:
                    c.execute(f"INSERT INTO {cfg['table']}({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
                              [cid, *vals.values()])
                c.commit()
                flash("Saved.")
                c.close()
                return redirect(url_for("entity", name=name, bg=bg_filter, isu=isu_filter, q=q_filter))
            except sqlite3.IntegrityError:
                flash("Employee number already exists in the list; it must be unique.", "error")

    edit = None
    if request.args.get("edit", type=int):
        edit = c.execute(f"SELECT * FROM {cfg['table']} WHERE id=?", (request.args.get("edit", type=int),)).fetchone()
        if edit:
            require_scope(c, edit["customer_id"])
    form_vals = dict(edit) if edit else (dict(request.form) if request.method == "POST" else {})
    if not form_vals and request.args.get("customer_id"):   # prefill from leaderboard completeness links
        form_vals = {"customer_id": request.args.get("customer_id")}

    records = scoped_records(c, name, bg_filter, isu_filter, q_filter, q_months)
    top = section_insights(c, name, records, bg_filter, isu_filter, q_months)

    fields = [(fld, lbl, kind, options_for(c, opts)) for fld, lbl, kind, opts in cfg["fields"]]
    labels = {fld: lbl for fld, lbl, *_ in cfg["fields"]}
    out = render_template("entity.html", name=name, cfg=cfg, fields=fields, labels=labels, records=records,
                          tree=customer_tree(c, bg_filter, isu_filter, form_vals.get("customer_id")),
                          form_vals=form_vals, edit=edit, bgs=bg_names(c), insights=top,
                          insight_scope=period_label(q_filter, q_months),
                          bg_filter=bg_filter, isu_filter=isu_filter, isu_rows=isu_rows, required=REQUIRED,
                          # AI chat panel (regular users), focused on the record / customer open in the form
                          **chat_ai.entity_widget_context(c, name, form_vals.get("customer_id"),
                                                          edit["id"] if edit else None))
    c.close()
    return out


@app.post("/e/<name>/<int:rid>/delete")
def entity_delete(name, rid):
    cfg = ENTITIES.get(name) or abort(404)
    c = conn()
    old = c.execute(f"SELECT customer_id FROM {cfg['table']} WHERE id=?", (rid,)).fetchone() or abort(404)
    require_scope(c, old["customer_id"])
    c.execute(f"DELETE FROM {cfg['table']} WHERE id=?", (rid,))
    c.commit()
    c.close()
    flash("Deleted.")
    return redirect(url_for("entity", name=name, bg=request.form.get("bg", ""), isu=request.form.get("isu", ""),
                            q=request.form.get("q", "")))


# ---------------------------------------------------------------- centrally managed lookups
@app.route("/lookups", methods=["GET", "POST"])
def lookups():
    if request.method == "POST" and not g.is_admin:
        abort(403)
    c = conn()
    if request.method == "POST":
        cat, val = request.form.get("category"), (request.form.get("value") or "").strip()
        if cat in LOOKUP_LABELS and val:
            try:
                c.execute("INSERT INTO lookup(category, value) VALUES (?,?)", (cat, val))
                c.commit()
                flash(f"Added '{val}'.")
            except sqlite3.IntegrityError:
                flash(f"'{val}' already exists.", "error")
        c.close()
        return redirect(url_for("lookups"))
    data = {cat: c.execute("SELECT * FROM lookup WHERE category=? ORDER BY id", (cat,)).fetchall()
            for cat in LOOKUP_LABELS}
    out = render_template("lookups.html", data=data, labels=LOOKUP_LABELS)
    c.close()
    return out


@app.post("/lookups/<int:lid>/delete")
@admin_required
def lookup_delete(lid):
    c = conn()
    c.execute("DELETE FROM lookup WHERE id=?", (lid,))
    c.commit()
    c.close()
    flash("Value removed (existing records keep their stored value).")
    return redirect(url_for("lookups"))


@app.route("/hierarchy")
def hierarchy():
    c = conn()
    bg_filter, isu_filter, isu_rows = read_filters(c)
    # LEFT JOINs so empty BGs / ISUs still show (and can be managed or deleted)
    bgs = [dict(r, isus=[]) for r in c.execute(
        "SELECT id, name, spoc_name, spoc_email, spoc_emp_no FROM bg" + (" WHERE name=?" if bg_filter else "") + " ORDER BY id",
        (bg_filter,) if bg_filter else ())]
    by_bg = {b["id"]: b for b in bgs}
    for r in c.execute("SELECT id, bg_id, name, spoc_name, spoc_email, spoc_emp_no FROM isu"
                       + (" WHERE name=?" if isu_filter else "") + " ORDER BY id",
                       (isu_filter,) if isu_filter else ()):
        if r["bg_id"] in by_bg:
            by_bg[r["bg_id"]]["isus"].append(dict(r, customers=[]))
    isus = {i["id"]: i for b in bgs for i in b["isus"]}
    usage = data_usage(c)
    mine = g.get("scope_cids")
    for r in c.execute("SELECT id, isu_id, name, spoc_name, spoc_email, spoc_emp_no FROM customer ORDER BY name"):
        if r["isu_id"] in isus and (mine is None or r["id"] in mine):
            isus[r["isu_id"]]["customers"].append(dict(r, used=usage.get(r["id"], 0)))
    if mine is not None:   # regular users: only the branches that lead to their own customers
        for b in bgs:
            b["isus"] = [i for i in b["isus"] if i["customers"]]
        bgs = [b for b in bgs if b["isus"]]
        isus = {i["id"]: i for b in bgs for i in b["isus"]}
    out = render_template("hierarchy.html", hbgs=bgs, n_isus=len(isus),
                          n_customers=sum(len(i["customers"]) for i in isus.values()), bgs=bg_names(c),
                          all_bgs=c.execute("SELECT id, name FROM bg ORDER BY id").fetchall(),
                          bg_filter=bg_filter, isu_filter=isu_filter, isu_rows=isu_rows)
    c.close()
    return out


CUSTOMER_DATA_TABLES = ["autonomy", "plan_item", "assessment", "deal", "touchpoint", "engineer", "asset"]


def data_usage(c):
    """{customer_id: number of data records referencing it}."""
    used = defaultdict(int)
    for t in CUSTOMER_DATA_TABLES:
        for r in c.execute(f"SELECT customer_id, COUNT(*) n FROM {t} GROUP BY customer_id"):
            used[r["customer_id"]] += r["n"]
    return used


EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")


def read_spoc(form):
    """(name, email, emp_no) from a form, validated; raises ValueError with a readable message."""
    name = " ".join((form.get("spoc_name") or "").split())
    email = (form.get("spoc_email") or "").strip().lower()
    emp = (form.get("spoc_emp_no") or "").strip()
    if email and not EMAIL_RE.match(email):
        raise ValueError(f"'{email}' is not a valid email ID.")
    if emp and not (emp.isdigit() and 4 <= len(emp) <= 10):
        raise ValueError("Emp No must be 4 to 10 digits.")
    return name or None, email or None, emp or None


def back_to_hierarchy():
    return redirect(url_for("hierarchy", bg=request.form.get("bg", ""), isu=request.form.get("isu", "")))


@app.post("/hierarchy/<kind>/add")
@admin_required
def hierarchy_add(kind):
    name = " ".join((request.form.get("name") or "").split())
    if not name:
        flash("Name is required.", "error")
        return back_to_hierarchy()
    c = conn()
    try:
        if kind == "bg":
            if c.execute("SELECT 1 FROM bg WHERE name=? COLLATE NOCASE", (name,)).fetchone():
                raise ValueError(f"BG '{name}' already exists.")
            c.execute("INSERT INTO bg(name, spoc_name, spoc_email, spoc_emp_no) VALUES (?,?,?,?)",
                      (name, *read_spoc(request.form)))
        elif kind == "isu":
            bg_id = request.form.get("parent_id", type=int)
            if not c.execute("SELECT 1 FROM bg WHERE id=?", (bg_id,)).fetchone():
                raise ValueError("Choose a valid BG.")
            # ISU names are unique across all BGs (filters identify an ISU by its name)
            if c.execute("SELECT 1 FROM isu WHERE name=? COLLATE NOCASE", (name,)).fetchone():
                raise ValueError(f"ISU '{name}' already exists.")
            c.execute("INSERT INTO isu(bg_id, name, spoc_name, spoc_email, spoc_emp_no) VALUES (?,?,?,?,?)",
                      (bg_id, name, *read_spoc(request.form)))
        elif kind == "customer":
            isu_id = request.form.get("parent_id", type=int)
            if not c.execute("SELECT 1 FROM isu WHERE id=?", (isu_id,)).fetchone():
                raise ValueError("Choose a valid ISU.")
            if c.execute("SELECT 1 FROM customer WHERE isu_id=? AND name=? COLLATE NOCASE", (isu_id, name)).fetchone():
                raise ValueError(f"Customer '{name}' already exists in this ISU.")
            spoc = read_spoc(request.form)
            c.execute("INSERT INTO customer(isu_id, name, spoc_name, spoc_email, spoc_emp_no) VALUES (?,?,?,?,?)",
                      (isu_id, name, *spoc))
        else:
            abort(404)
        c.commit()
        flash(f"Added {kind.upper() if kind != 'customer' else 'customer'} '{name}'.")
    except ValueError as e:
        flash(str(e), "error")
    finally:
        c.close()
    return back_to_hierarchy()


@app.post("/hierarchy/<kind>/<int:rid>/rename")
@admin_required
def hierarchy_rename(kind, rid):
    table = {"bg": "bg", "isu": "isu", "customer": "customer"}.get(kind) or abort(404)
    name = " ".join((request.form.get("name") or "").split())
    c = conn()
    row = c.execute(f"SELECT * FROM {table} WHERE id=?", (rid,)).fetchone() or abort(404)
    try:
        if not name:
            raise ValueError("Name is required.")
        if kind == "bg":
            clash = c.execute("SELECT 1 FROM bg WHERE name=? COLLATE NOCASE AND id<>?", (name, rid)).fetchone()
        elif kind == "isu":
            clash = c.execute("SELECT 1 FROM isu WHERE name=? COLLATE NOCASE AND id<>?", (name, rid)).fetchone()
        else:
            clash = c.execute("SELECT 1 FROM customer WHERE isu_id=? AND name=? COLLATE NOCASE AND id<>?",
                              (row["isu_id"], name, rid)).fetchone()
        if clash:
            raise ValueError(f"'{name}' already exists.")
        c.execute(f"UPDATE {table} SET name=? WHERE id=?", (name, rid))
        if kind in ("bg", "isu") and name != row["name"]:   # keep BG/ISU-limited users attached after a rename
            col = "scope_bg" if kind == "bg" else "scope_isu"
            c.execute(f"UPDATE app_user SET {col}=? WHERE {col}=?", (name, row["name"]))
        c.commit()
        flash(f"Renamed '{row['name']}' to '{name}'.")
    except ValueError as e:
        flash(str(e), "error")
    finally:
        c.close()
    # keep the filter pointing at the renamed item
    bg, isu = request.form.get("bg", ""), request.form.get("isu", "")
    if kind == "bg" and bg == row["name"]:
        bg = name
    if kind == "isu" and isu == row["name"]:
        isu = name
    return redirect(url_for("hierarchy", bg=bg, isu=isu))


@app.post("/hierarchy/<kind>/<int:rid>/edit")
@admin_required
def hierarchy_edit(kind, rid):
    """Admin-only: name and Account AI-SPOC (name, email ID, emp no) of a BG, ISU or customer."""
    table = {"bg": "bg", "isu": "isu", "customer": "customer"}.get(kind) or abort(404)
    label = {"bg": "BG", "isu": "ISU", "customer": "Customer"}[kind]
    c = conn()
    row = c.execute(f"SELECT * FROM {table} WHERE id=?", (rid,)).fetchone() or abort(404)
    name = " ".join((request.form.get("name") or "").split())
    saved = False
    try:
        if not name:
            raise ValueError(f"{label} name is required.")
        if kind == "bg":
            clash = c.execute("SELECT 1 FROM bg WHERE name=? COLLATE NOCASE AND id<>?", (name, rid)).fetchone()
        elif kind == "isu":   # ISU names are unique across all BGs (filters identify an ISU by name)
            clash = c.execute("SELECT 1 FROM isu WHERE name=? COLLATE NOCASE AND id<>?", (name, rid)).fetchone()
        else:
            clash = c.execute("SELECT 1 FROM customer WHERE isu_id=? AND name=? COLLATE NOCASE AND id<>?",
                              (row["isu_id"], name, rid)).fetchone()
        if clash:
            raise ValueError(f"{label} '{name}' already exists" + (" in this ISU." if kind == "customer" else "."))
        spoc = read_spoc(request.form)
        c.execute(f"UPDATE {table} SET name=?, spoc_name=?, spoc_email=?, spoc_emp_no=? WHERE id=?", (name, *spoc, rid))
        if kind in ("bg", "isu") and name != row["name"]:   # keep BG/ISU-limited users attached after a rename
            col = "scope_bg" if kind == "bg" else "scope_isu"
            c.execute(f"UPDATE app_user SET {col}=? WHERE {col}=?", (name, row["name"]))
        c.commit()
        saved = True
        flash(f"Saved {label} '{name}'.")
    except ValueError as e:
        flash(str(e), "error")
    finally:
        c.close()
    # keep the filter pointing at a renamed BG / ISU
    bg, isu = request.form.get("bg", ""), request.form.get("isu", "")
    if saved and kind == "bg" and bg == row["name"]:
        bg = name
    if saved and kind == "isu" and isu == row["name"]:
        isu = name
    return redirect(url_for("hierarchy", bg=bg, isu=isu))


@app.post("/hierarchy/<kind>/<int:rid>/delete")
@admin_required
def hierarchy_delete(kind, rid):
    c = conn()
    try:
        if kind == "bg":
            row = c.execute("SELECT name FROM bg WHERE id=?", (rid,)).fetchone() or abort(404)
            if c.execute("SELECT 1 FROM isu WHERE bg_id=?", (rid,)).fetchone():
                raise ValueError(f"BG '{row['name']}' still has ISUs. Delete them first.")
            if c.execute("SELECT 1 FROM app_user WHERE scope_bg=?", (row["name"],)).fetchone():
                raise ValueError(f"BG '{row['name']}' has users limited to it. Change those users first.")
            c.execute("DELETE FROM bg WHERE id=?", (rid,))
        elif kind == "isu":
            row = c.execute("SELECT name FROM isu WHERE id=?", (rid,)).fetchone() or abort(404)
            if c.execute("SELECT 1 FROM customer WHERE isu_id=?", (rid,)).fetchone():
                raise ValueError(f"ISU '{row['name']}' still has customers. Delete them first.")
            if c.execute("SELECT 1 FROM app_user WHERE scope_isu=?", (row["name"],)).fetchone():
                raise ValueError(f"ISU '{row['name']}' has users limited to it. Change those users first.")
            c.execute("DELETE FROM isu WHERE id=?", (rid,))
        elif kind == "customer":
            row = c.execute("SELECT name FROM customer WHERE id=?", (rid,)).fetchone() or abort(404)
            n = data_usage(c).get(rid, 0)
            if n:
                raise ValueError(f"Customer '{row['name']}' has {n} data record(s) and cannot be deleted.")
            c.execute("DELETE FROM customer WHERE id=?", (rid,))
        else:
            abort(404)
        c.commit()
        flash(f"Deleted '{row['name']}'.")
    except ValueError as e:
        flash(str(e), "error")
    finally:
        c.close()
    return back_to_hierarchy()


db.init_db()

# AI chat window (users add records by chatting; saved only after they confirm a draft)
import chat_ai  # noqa: E402
chat_ai.init(app, ENTITIES=ENTITIES, REQUIRED=REQUIRED, options_for=options_for, customer_in_scope=customer_in_scope,
             scoped_customers=scoped_customers, scoped_records=scoped_records, conn=conn, db=db,
             IntegrityError=sqlite3.IntegrityError)

# AI Agents page (admin only): draft reminder emails as .txt files
import agents_ai  # noqa: E402
agents_ai.init(app, conn=conn, db=db, completeness=completeness, current_month=current_month, SECTIONS=SECTIONS,
               api_key=chat_ai.api_key, maturity_by_month=maturity_by_month)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
