# AI Synapse - TCS AI Journey Insights Portal

AI Synapse is a Flask and SQLite portal. It collects data on AI service autonomy, key deals, customer touchpoints, distinguished engineers and asset contributions, and shows a running BG-wise leaderboard.

## Run

```
pip install -r requirements.txt
python db.py        # (re)create aidash.db with sample data; optional, since the app seeds on first start
python app.py       # http://127.0.0.1:5000
```

## Pages
- **Leaderboard** (`/`): one running leaderboard per metric, ranked by BG, with a small-font month-on-month table for FY27 (Apr-26 to the current month). The latest month is highlighted. Click a BG to see its ISUs.
- **AI Service Autonomy**: profile, 30-60-90 plan and assessment history for each customer. Monthly maturity is derived, never typed: it is the level of the latest assessment on or before each month's end.
- **Key Deals, Customer Touchpoints, Distinguished Engineers, Asset Contribution**: each is a single page with an entry form and a records list. Records can be edited and deleted, and the list can be filtered by BG. Employee number must be unique.
- **Lookups**: centrally managed values for engagement type, DE role type and asset status.
- **Hierarchy**: BG > ISU > customers.
