"""Top-N insights for the data pages.

Each generator inspects the records currently in scope (BG / ISU / quarter filters applied) and
returns candidate insights with a significance score; the page shows the highest-scoring ones.
Insight: {"title", "text", "tone": good|warn|info, "score"}.
"""
from collections import Counter, defaultdict

import db


def _ins(title, text, tone, score):
    return {"title": title, "text": text, "tone": tone, "score": score}


def _pct(a, b):
    return round(100 * a / b) if b else 0


def _n(n, word, plural=None):
    return f"{n} {word if n == 1 else (plural or word + 's')}"


def _group_key(r, level):
    return r["customer"] if level == "Customer" else r["isu"] if level == "ISU" else r["bg"]


def _mom(records, month_field, months, value=lambda r: 1):
    """(last month, prev month, last value, prev value) over the scoped months, or None."""
    if len(months) < 2:
        return None
    last, prev = months[-1], months[-2]
    lv = sum(value(r) for r in records if r[month_field] == last)
    pv = sum(value(r) for r in records if r[month_field] == prev)
    return last, prev, lv, pv


def _trend(label, unit, mom):
    if not mom:
        return None
    last, prev, lv, pv = mom
    if pv == 0 and lv == 0:
        return None
    if pv == 0:
        return _ins(f"{label} picking up", f"{lv} {unit} in {db.month_label(last)}, up from none in "
                    f"{db.month_label(prev)}.", "good", 55)
    ch = round(100 * (lv - pv) / pv)
    tone = "good" if ch > 0 else "warn" if ch < 0 else "info"
    word = "up" if ch > 0 else "down" if ch < 0 else "flat"
    return _ins(f"{label} {word} {abs(ch)}% month on month" if ch else f"{label} flat month on month",
                f"{lv} {unit} in {db.month_label(last)} vs {pv} in {db.month_label(prev)}.",
                tone, 45 + min(40, abs(ch) * 0.4))


# ------------------------------------------------------------------ Key deals
def deals(records, level, months, n_accounts):
    out = []
    won = [r for r in records if r["status"] == "Won"]
    lost = [r for r in records if r["status"] == "Lost"]
    closed = len(won) + len(lost)
    if closed >= 3:
        rate = len(won) / closed
        by = Counter(_group_key(r, level) for r in won)
        best = f" {by.most_common(1)[0][0]} leads with {_n(by.most_common(1)[0][1], 'win')}." if by else ""
        out.append(_ins(f"Win rate {round(rate * 100)}%",
                        f"{len(won)} won vs {len(lost)} lost of {closed} closed deals.{best}",
                        "good" if rate >= 0.5 else "warn", 55 + abs(rate - 0.5) * 50))
    if len(lost) >= 2:
        comp = Counter(r["competitor"] for r in lost if r["competitor"])
        reason = Counter(r["not_resonated"] for r in lost if r["not_resonated"])
        if comp:
            c, n = comp.most_common(1)[0]
            why = f" Most common reason: {reason.most_common(1)[0][0].lower()}." if reason else ""
            out.append(_ins(f"Losing most often to {c}", f"{c} was the competitor in {n} of {len(lost)} lost deals.{why}",
                            "warn", 60 + _pct(n, len(lost)) * 0.3))
    open_ = [r for r in records if r["status"] not in ("Won", "Lost")]
    if open_:
        val = sum(r["deal_value"] or 0 for r in open_)
        neg = [r for r in open_ if r["status"] == "Negotiation"]
        nv = sum(r["deal_value"] or 0 for r in neg)
        tail = (f" {len(neg)} in Negotiation (USD {nv:.1f}M) {'is' if len(neg) == 1 else 'are'} closest to closing."
                if neg else " None are in Negotiation yet.")
        out.append(_ins(f"USD {val:.1f}M open pipeline", f"{_n(len(open_), 'active deal')}.{tail}", "info",
                        50 + min(30, len(neg) * 5)))
    if won:
        big = max(won, key=lambda r: r["deal_value"] or 0)
        out.append(_ins("Largest win", f"{big['deal_name']} ({big['customer']}): USD {big['deal_value'] or 0:.1f}M"
                        + (f", won against {big['competitor']}." if big["competitor"] else "."), "good", 48))
    return out


# ------------------------------------------------------------------ Customer touchpoints
def touchpoints(records, level, months, n_accounts):
    out = []
    t = _trend("Touchpoints", "touchpoints", _mom(records, "reporting_month", months))
    if t:
        out.append(t)
    if records:
        types = Counter(r["engagement_type"] for r in records if r["engagement_type"])
        cxo = types.get("CXO connect", 0)
        share = _pct(cxo, len(records))
        if share < 20:
            out.append(_ins("Low CXO-level engagement", f"CXO connects are only {share}% of {len(records)} "
                            f"touchpoints; {types.most_common(1)[0][0]} is the most common type.", "warn", 62 + (20 - share)))
        else:
            out.append(_ins("Strong CXO-level engagement", f"{share}% of touchpoints are CXO connects ({cxo} of {len(records)}).",
                            "good", 50))
        focus = Counter(f.strip() for r in records for f in (r["focus_areas"] or "").split(",") if f.strip())
        if focus:
            (f1, n1), *rest = focus.most_common(2)
            second = f", followed by {rest[0][0]} ({rest[0][1]})" if rest else ""
            out.append(_ins(f"Top focus: {f1}", f"Discussed in {_n(n1, 'touchpoint')}{second}.", "info", 55))
        touched = {r["customer"] for r in records}
        if n_accounts:
            miss = n_accounts - len(touched)
            if miss > 0:
                out.append(_ins(f"{_n(miss, 'account')} not engaged", f"{miss} of {n_accounts} accounts in scope "
                                f"{'has' if miss == 1 else 'have'} no touchpoint in this period.", "warn",
                                50 + _pct(miss, n_accounts) * 0.35))
    return out


# ------------------------------------------------------------------ Distinguished engineers
def engineers(records, level, months, n_accounts):
    out = []
    n = len(records)
    if n:
        roles = Counter(r["role_type"] for r in records if r["role_type"])
        # roles defined centrally but with no DE in scope count as 0
        for role in db_roles():
            roles.setdefault(role, 0)
        if len(roles) >= 2:
            low, ln = min(roles.items(), key=lambda kv: (kv[1], kv[0]))
            top, tn = roles.most_common(1)[0]
            if ln < tn:
                detail = (f"No {low} among the {n} DEs in scope" if ln == 0 else
                          f"{low}: only {ln} of {n} DEs ({_pct(ln, n)}%)")
                out.append(_ins(f"{low} is the scarcest role", f"{detail}; {top} leads with {tn} ({_pct(tn, n)}%).",
                                "warn" if _pct(ln, n) < 25 else "info", 55 + max(0, 30 - _pct(ln, n))))
        locs = Counter(r["location"] for r in records if r["location"])
        if len(locs) >= 2:
            (l1, n1), (l2, n2) = locs.most_common(2)
            share = _pct(n1 + n2, n)
            out.append(_ins(f"{share}% concentrated in two locations", f"{l1} ({n1}) and {l2} ({n2}) host the most DEs "
                            f"across {len(locs)} locations.", "info", 40 + share * 0.3))
        with_de = {r["customer"] for r in records}
        if n_accounts:
            miss = n_accounts - len(with_de)
            if miss > 0:
                out.append(_ins(f"{_n(miss, 'account')} without a DE", f"{miss} of {n_accounts} accounts in scope "
                                f"{'has' if miss == 1 else 'have'} no Distinguished Engineer added in this period.",
                                "warn", 52 + _pct(miss, n_accounts) * 0.3))
    t = _trend("DE additions", "engineers added", _mom(records, "month_added", months))
    if t:
        out.append(t)
    return out


# ------------------------------------------------------------------ Asset contribution
def assets(records, level, months, n_accounts):
    out = []
    cnt = lambda r: r["asset_count"] or 0
    total = sum(cnt(r) for r in records)
    if total:
        core = sum(cnt(r) for r in records if r["core_platform"] == "Y")
        share = _pct(core, total)
        out.append(_ins(f"{share}% reach the TCS core platform", f"{core} of {total} contributed assets were added to "
                        f"the core platform.", "good" if share >= 50 else "warn", 55 + abs(share - 50) * 0.4))
        early = sum(cnt(r) for r in records if r["status"] in ("Ideation", "In development"))
        if early:
            out.append(_ins(f"{_n(early, 'asset')} not yet usable", f"{_pct(early, total)}% are still in Ideation or "
                            f"In development; push these to Ready for use.", "warn", 50 + _pct(early, total) * 0.3))
        by = defaultdict(int)
        for r in records:
            by[_group_key(r, level)] += cnt(r)
        if len(by) >= 2:
            g, v = max(by.items(), key=lambda kv: kv[1])
            out.append(_ins(f"Top contributor: {g}", f"{v} assets ({_pct(v, total)}% of {total}).", "good", 50))
    t = _trend("Asset contributions", "assets", _mom(records, "contribution_month", months, cnt))
    if t:
        out.append(t)
    return out


# ------------------------------------------------------------------ AI service autonomy
def maturity_snapshot(accounts, mat, month):
    """Counts of accounts by maturity band as of `month` (derived level of latest assessment)."""
    lv = lambda l: db.LEVELS.index(l) if l in db.LEVELS else -1
    levels = [mat.get(r["id"], {}).get(month) for r in accounts]
    n = len(levels)
    l3 = sum(1 for l in levels if lv(l) >= 3)
    l2 = sum(1 for l in levels if l == "L2")
    not_assessed = sum(1 for l in levels if l is None)
    below = n - l3 - l2                     # L0, L1 or not yet assessed
    return {"n": n, "month": db.month_label(month), "l3": l3, "l2": l2, "below": below,
            "not_assessed": not_assessed, "pct_l3": _pct(l3, n), "pct_l2": _pct(l2, n), "pct_below": _pct(below, n),
            "at_least_l2": l3 + l2, "pct_at_least_l2": _pct(l3 + l2, n)}


def autonomy(accounts, mat, months, last_assessed, plans, today, current_quarter, k=3):
    """accounts: scoped rows (id, name, target_level, target_quarter, workshop_completed, mega_ai_journey,
    headcount_band); mat: {cid: {month: level}}; last_assessed: {cid: 'YYYY-MM-DD'};
    plans: rows (customer_id, status, due_date); today: 'YYYY-MM-DD'."""
    from datetime import date, timedelta
    lv = lambda l: db.LEVELS.index(l) if l in db.LEVELS else -1
    n = len(accounts)
    if not n:
        return []
    out = []
    first, last = months[0], months[-1]
    level_at = lambda cid, m: mat.get(cid, {}).get(m)

    # maturity progression to L3+
    if len(months) >= 2:
        a = sum(1 for r in accounts if lv(level_at(r["id"], first)) >= 3)
        b = sum(1 for r in accounts if lv(level_at(r["id"], last)) >= 3)
        if a or b:
            d = b - a
            out.append(_ins(f"Accounts at L3+ {'up' if d > 0 else 'down' if d < 0 else 'flat'}"
                            + (f" {abs(d)}" if d else "") + f" since {db.month_label(first)}",
                            f"{a} → {b} of {n} accounts at L3 or above between {db.month_label(first)} and "
                            f"{db.month_label(last)}.", "good" if d > 0 else "warn" if d < 0 else "info",
                            55 + min(30, abs(d) * 3)))
        # biggest improver
        best = max(accounts, key=lambda r: (lv(level_at(r["id"], last)) - lv(level_at(r["id"], first))
                                            if level_at(r["id"], first) else -9))
        f_l, l_l = level_at(best["id"], first), level_at(best["id"], last)
        if f_l and l_l and lv(l_l) - lv(f_l) >= 2:
            out.append(_ins(f"Fastest mover: {best['name']}", f"Moved from {f_l} to {l_l} between "
                            f"{db.month_label(first)} and {db.month_label(last)}.", "good", 50 + (lv(l_l) - lv(f_l)) * 4))

    # gap to target
    below = [r for r in accounts if r["target_level"] in db.LEVELS and lv(level_at(r["id"], last)) < lv(r["target_level"])]
    if below:
        due_now = sum(1 for r in below if (r["target_quarter"] or "").strip().upper() == current_quarter.upper())
        tail = f" {_n(due_now, 'account')} {'is' if due_now == 1 else 'are'} due to reach target in {current_quarter}." if due_now else ""
        p = _pct(len(below), n)
        out.append(_ins(f"{p}% of accounts below target level", f"{len(below)} of {n} accounts haven't reached "
                        f"their target maturity yet.{tail}", "warn", 50 + p * 0.25 + min(15, due_now * 2)))

    # stale assessments (none in the last 90 days of the period end)
    cutoff = (date.fromisoformat(db.month_end(last)) - timedelta(days=90)).isoformat()
    never = sum(1 for r in accounts if r["id"] not in last_assessed)
    stale = sum(1 for r in accounts if r["id"] in last_assessed and last_assessed[r["id"]] < cutoff)
    if stale or never:
        p = _pct(stale + never, n)
        extra = f" ({never} never assessed)" if never else ""
        out.append(_ins(f"{_n(stale + never, 'account')} need reassessment", f"No assessment in the 90 days to "
                        f"{db.month_label(last)}{extra}. Maturity figures for these accounts may be out of date.",
                        "warn", 48 + p * 0.35))

    # 30-60-90 plan execution
    scope = {r["id"] for r in accounts}
    mine = [p for p in plans if p["customer_id"] in scope]
    overdue = [p for p in mine if p["due_date"] and p["due_date"] < today and p["status"] != "Done"]
    blocked = sum(1 for p in mine if p["status"] == "Blocked")
    if overdue or blocked:
        accts = len({p["customer_id"] for p in overdue})
        out.append(_ins(f"{_n(len(overdue), 'overdue plan item')}",
                        f"Across {_n(accts, 'account')}; {blocked} plan item{'s are' if blocked != 1 else ' is'} blocked. "
                        f"Review owners and due dates.", "warn", 52 + min(30, len(overdue) * 0.25)))

    # AI workshop coverage
    ws = sum(1 for r in accounts if r["workshop_completed"] == "Y")
    p = _pct(ws, n)
    mega_no_ws = sum(1 for r in accounts if r["mega_ai_journey"] == "Y" and r["workshop_completed"] != "Y")
    tail = f" {mega_no_ws} Mega AI Journey account{'s have' if mega_no_ws != 1 else ' has'} not done it yet." if mega_no_ws else ""
    if p < 70:
        out.append(_ins(f"Only {p}% completed the AI workshop", f"{ws} of {n} accounts.{tail}", "warn", 50 + (70 - p) * 0.4))
    else:
        out.append(_ins(f"{p}% completed the AI workshop", f"{ws} of {n} accounts.{tail}", "good", 42))

    # headcount still pending
    pend = sum(1 for r in accounts if r["headcount_band"] == "Pending business confirmation")
    if pend:
        out.append(_ins(f"{_n(pend, 'account')}: headcount pending", f"Headcount band awaits business confirmation "
                        f"for {_pct(pend, n)}% of accounts in scope.", "info", 38 + _pct(pend, n) * 0.3))

    out.sort(key=lambda i: -i["score"])
    return out[:k]


def db_roles():
    c = db.connect()
    try:
        return [r["value"] for r in c.execute("SELECT value FROM lookup WHERE category='role_type'")]
    finally:
        c.close()


GENERATORS = {"deals": deals, "touchpoints": touchpoints, "engineers": engineers, "assets": assets}


def top_insights(name, records, level, months, n_accounts, k=2):
    cands = [i for i in GENERATORS[name](records, level, months, n_accounts) if i]
    cands.sort(key=lambda i: -i["score"])
    return cands[:k]
