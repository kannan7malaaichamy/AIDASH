"""SQLite Cloud over HTTPS (port 443) with the small part of the sqlite3 API that AIDASH uses.

Why HTTPS: the normal SQLite Cloud driver needs outbound TCP port 8860, which is blocked on this
network. This adapter sends each statement to SQLite Cloud's Weblite SQL endpoint instead.

Differences from a local sqlite3 file (keep in mind):
* Every statement is saved immediately (auto-commit). commit() does nothing and rollback() cannot
  undo earlier statements, so a multi-step save that fails half-way may leave the first steps saved.
* Each statement is one HTTPS round trip (~0.3 s), so pages are slower than with a local file.
"""
import http.client
import json
import sqlite3
import threading
from urllib.parse import parse_qs, urlparse

_local = threading.local()   # one kept-alive HTTPS connection per server thread


class Row:
    """Behaves like sqlite3.Row: row["col"], row[0], tuple unpacking, dict(row), row.keys()."""
    __slots__ = ("_keys", "_vals")

    def __init__(self, keys, vals):
        self._keys, self._vals = keys, vals

    def keys(self):
        return list(self._keys)

    def __getitem__(self, k):
        if isinstance(k, (int, slice)):
            return self._vals[k]
        try:
            return self._vals[self._keys.index(k)]
        except ValueError:
            for i, name in enumerate(self._keys):   # sqlite3.Row is case-insensitive
                if name.lower() == str(k).lower():
                    return self._vals[i]
            raise IndexError(f"No item with that key: {k}")

    def __iter__(self):
        return iter(self._vals)

    def __len__(self):
        return len(self._vals)

    def __eq__(self, other):
        return isinstance(other, Row) and self._keys == other._keys and self._vals == other._vals

    def __repr__(self):
        return f"Row({dict(zip(self._keys, self._vals))!r})"


class Cursor:
    def __init__(self, rows, lastrowid=None, rowcount=-1):
        self._rows, self._i = rows, 0
        self.lastrowid, self.rowcount = lastrowid, rowcount

    def fetchone(self):
        if self._i >= len(self._rows):
            return None
        self._i += 1
        return self._rows[self._i - 1]

    def fetchall(self):
        out, self._i = self._rows[self._i:], len(self._rows)
        return out

    def __iter__(self):
        return iter(self.fetchall())


def _value(v, decl_type):
    if isinstance(v, dict) and v.get("type") == "Buffer":   # BLOB
        return bytes(v.get("data") or [])
    if isinstance(v, int) and not isinstance(v, bool) and (decl_type or "").upper() in ("REAL", "FLOAT", "DOUBLE"):
        return float(v)   # JSON drops the ".0" of REAL values; sqlite3 would return a float
    return v


class Connection:
    def __init__(self, url):
        u = urlparse(url)
        if u.scheme != "sqlitecloud" or not u.hostname or not u.path.strip("/"):
            raise ValueError("Expected sqlitecloud://<host>:<port>/<database>?apikey=<key>")
        if not parse_qs(u.query).get("apikey"):
            raise ValueError("The SQLite Cloud connection string has no apikey.")
        self.host, self.database, self._auth = u.hostname, u.path.strip("/"), "Bearer " + url
        self.row_factory = None   # accepted for compatibility; rows are always Row objects

    # -- transport
    def _http(self):
        h = getattr(_local, "conns", {}).get(self.host)
        if h is None:
            h = http.client.HTTPSConnection(self.host, 443, timeout=60)
            _local.__dict__.setdefault("conns", {})[self.host] = h
        return h

    def _post(self, body):
        payload = json.dumps(body)
        headers = {"Content-Type": "application/json", "Authorization": self._auth}
        for attempt in (1, 2):   # a kept-alive connection may have been closed by the server: retry once
            h = self._http()
            try:
                h.request("POST", "/v2/weblite/sql", payload, headers)
                r = h.getresponse()
                return r.status, json.loads(r.read() or b"{}")
            except (http.client.HTTPException, OSError):
                h.close()
                _local.conns.pop(self.host, None)
                if attempt == 2:
                    raise sqlite3.OperationalError(f"Cannot reach SQLite Cloud at {self.host} over HTTPS.")

    # -- sqlite3-style API
    def execute(self, sql, params=()):
        body = {"sql": sql, "database": self.database}
        if params:
            if isinstance(params, dict):
                raise sqlite3.ProgrammingError("Named parameters are not supported; use ? placeholders.")
            body["bind"] = [p.hex() if isinstance(p, bytes) else p for p in params]
        status, res = self._post(body)
        if status != 200 or "error" in res:
            msg = (res.get("error") or {}).get("detail") or f"SQLite Cloud HTTP {status}"
            if "constraint" in msg.lower():
                raise sqlite3.IntegrityError(msg)
            raise sqlite3.OperationalError(msg)
        data = res.get("data")
        meta = res.get("metadata") or {}
        cols = meta.get("columns") or []
        names = [c.get("name") for c in cols]
        if names[:3] == ["TYPE", "INDEX", "ROWID"] and "CHANGES" in names and isinstance(data, list) \
                and data and isinstance(data[0], list):   # result of INSERT/UPDATE/DELETE/DDL
            info = dict(zip(names, data[0]))
            return Cursor([], lastrowid=info.get("ROWID"), rowcount=info.get("CHANGES", -1))
        rows = []
        types = [c.get("type") for c in cols]
        for d in data or []:
            if isinstance(d, dict):
                keys = names if len(names) == len(d) else list(d)
                vals = [_value(d.get(k), t) for k, t in zip(keys, types + [None] * len(keys))]
            else:
                keys, vals = names, [_value(v, t) for v, t in zip(d, types)]
            rows.append(Row(keys, vals))
        return Cursor(rows)

    def executemany(self, sql, seq):
        for params in seq:
            self.execute(sql, params)

    def executescript(self, script):
        self.execute(script)   # the endpoint runs multiple ;-separated statements in one request

    def commit(self):
        pass   # every statement is already saved (auto-commit)

    def rollback(self):
        pass   # not possible over the stateless HTTPS API (see module docstring)

    def close(self):
        pass   # the HTTPS connection is kept alive for the next request on this thread


def connect(url):
    return Connection(url)
